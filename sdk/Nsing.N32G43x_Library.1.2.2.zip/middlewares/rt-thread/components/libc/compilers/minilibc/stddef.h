/*
 * Copyright (c) 2006-2018, RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 */
#ifndef __STDDEF_H__
#define __STDDEF_H__

#include <sys/types.h>
typedef signed long ptrdiff_t;

#endif
