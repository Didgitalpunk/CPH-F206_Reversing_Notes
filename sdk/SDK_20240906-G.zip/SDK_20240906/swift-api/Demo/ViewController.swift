//
//  ViewController.swift
//  Demo
//
//  Created by c10udx on 2024/8/7.
//

import CoreBluetooth
import GReader
import UIKit

class ViewController: UIViewController {
    var gbleManager = GBleManager.instance
    var deviceListData: [DeviceInfo] = []
    var peripheral: CBPeripheral!
    var gbleDevice: GBleDevice!
    var client: GClient! = .init()
    var textView: UITextView!

    override func viewDidLoad() {
        super.viewDidLoad()

        view.backgroundColor = .white

        let openblebtn = UIButton(type: .system)
        openblebtn.setTitle("searchBLE", for: .normal)
        openblebtn.tintColor = .white
        openblebtn.backgroundColor = .systemBlue
        openblebtn.frame = CGRect(x: 20, y: 50, width: 100, height: 50)
        openblebtn.addTarget(self, action: #selector(searchBLE), for: .touchUpInside)
        view.addSubview(openblebtn)

        let connectbtn = UIButton(type: .system)
        connectbtn.setTitle("connectBLE", for: .normal)
        connectbtn.tintColor = .white
        connectbtn.backgroundColor = .systemBlue
        connectbtn.frame = CGRect(x: 150, y: 50, width: 100, height: 50)
        connectbtn.addTarget(self, action: #selector(connectBLE), for: .touchUpInside)
        view.addSubview(connectbtn)

        let closeblebtn = UIButton(type: .system)
        closeblebtn.setTitle("closeBLE", for: .normal)
        closeblebtn.tintColor = .white
        closeblebtn.backgroundColor = .systemBlue
        closeblebtn.frame = CGRect(x: 270, y: 50, width: 100, height: 50)
        closeblebtn.addTarget(self, action: #selector(closeBLE), for: .touchUpInside)
        view.addSubview(closeblebtn)

        let readbtn = UIButton(type: .system)
        readbtn.setTitle("readEpc", for: .normal)
        readbtn.tintColor = .white
        readbtn.backgroundColor = .systemBlue
        readbtn.frame = CGRect(x: 20, y: 120, width: 100, height: 50)
        readbtn.addTarget(self, action: #selector(readEpc), for: .touchUpInside)
        view.addSubview(readbtn)

        let writebtn = UIButton(type: .system)
        writebtn.setTitle("writeEpc", for: .normal)
        writebtn.tintColor = .white
        writebtn.backgroundColor = .systemBlue
        writebtn.frame = CGRect(x: 150, y: 120, width: 100, height: 50)
        writebtn.addTarget(self, action: #selector(writeEpc), for: .touchUpInside)
        view.addSubview(writebtn)

        let stopbtn = UIButton(type: .system)
        stopbtn.setTitle("stop", for: .normal)
        stopbtn.tintColor = .white
        stopbtn.backgroundColor = .systemBlue
        stopbtn.frame = CGRect(x: 270, y: 120, width: 100, height: 50)
        stopbtn.addTarget(self, action: #selector(stop), for: .touchUpInside)
        view.addSubview(stopbtn)

        let getVerBtn = UIButton(type: .system)
        getVerBtn.setTitle("getVer", for: .normal)
        getVerBtn.tintColor = .white
        getVerBtn.backgroundColor = .systemBlue
        getVerBtn.frame = CGRect(x: 20, y: 190, width: 100, height: 50)
        getVerBtn.addTarget(self, action: #selector(getVer), for: .touchUpInside)
        view.addSubview(getVerBtn)

        let getPowerBtn = UIButton(type: .system)
        getPowerBtn.setTitle("getPower", for: .normal)
        getPowerBtn.tintColor = .white
        getPowerBtn.backgroundColor = .systemBlue
        getPowerBtn.frame = CGRect(x: 150, y: 190, width: 100, height: 50)
        getPowerBtn.addTarget(self, action: #selector(getPower), for: .touchUpInside)
        view.addSubview(getPowerBtn)

        let setPowerBtn = UIButton(type: .system)
        setPowerBtn.setTitle("setPower", for: .normal)
        setPowerBtn.tintColor = .white
        setPowerBtn.backgroundColor = .systemBlue
        setPowerBtn.frame = CGRect(x: 270, y: 190, width: 100, height: 50)
        setPowerBtn.addTarget(self, action: #selector(setPower), for: .touchUpInside)
        view.addSubview(setPowerBtn)

        let rdBtn = UIButton(type: .system)
        rdBtn.setTitle("restoreDefault", for: .normal)
        rdBtn.tintColor = .white
        rdBtn.backgroundColor = .systemBlue
        rdBtn.frame = CGRect(x: 20, y: 260, width: 100, height: 50)
        rdBtn.addTarget(self, action: #selector(restoreDefault), for: .touchUpInside)
        view.addSubview(rdBtn)

        let getGpiTriggerBtn = UIButton(type: .system)
        getGpiTriggerBtn.setTitle("getGpiTrigger", for: .normal)
        getGpiTriggerBtn.tintColor = .white
        getGpiTriggerBtn.backgroundColor = .systemBlue
        getGpiTriggerBtn.frame = CGRect(x: 150, y: 260, width: 100, height: 50)
        getGpiTriggerBtn.addTarget(self, action: #selector(getGpiTrigger), for: .touchUpInside)
        view.addSubview(getGpiTriggerBtn)

        let setGpiTriggerBtn = UIButton(type: .system)
        setGpiTriggerBtn.setTitle("setGpiTrigger", for: .normal)
        setGpiTriggerBtn.tintColor = .white
        setGpiTriggerBtn.backgroundColor = .systemBlue
        setGpiTriggerBtn.frame = CGRect(x: 270, y: 260, width: 100, height: 50)
        setGpiTriggerBtn.addTarget(self, action: #selector(setGpiTrigger), for: .touchUpInside)
        view.addSubview(setGpiTriggerBtn)

        let getUsbKeyBtn = UIButton(type: .system)
        getUsbKeyBtn.setTitle("getUsbKeyboard", for: .normal)
        getUsbKeyBtn.tintColor = .white
        getUsbKeyBtn.backgroundColor = .systemBlue
        getUsbKeyBtn.frame = CGRect(x: 20, y: 330, width: 100, height: 50)
        getUsbKeyBtn.addTarget(self, action: #selector(getUsbKeyboard), for: .touchUpInside)
        view.addSubview(getUsbKeyBtn)

        let setUsbKeyBtn = UIButton(type: .system)
        setUsbKeyBtn.setTitle("setUsbKeyboard", for: .normal)
        setUsbKeyBtn.tintColor = .white
        setUsbKeyBtn.backgroundColor = .systemBlue
        setUsbKeyBtn.frame = CGRect(x: 150, y: 330, width: 100, height: 50)
        setUsbKeyBtn.addTarget(self, action: #selector(setUsbKeyboard), for: .touchUpInside)
        view.addSubview(setUsbKeyBtn)

        let getBasebandBtn = UIButton(type: .system)
        getBasebandBtn.setTitle("getEPCBaseband", for: .normal)
        getBasebandBtn.tintColor = .white
        getBasebandBtn.backgroundColor = .systemBlue
        getBasebandBtn.frame = CGRect(x: 270, y: 330, width: 100, height: 50)
        getBasebandBtn.addTarget(self, action: #selector(getBaseband), for: .touchUpInside)
        view.addSubview(getBasebandBtn)

        let getAutoDormancyBtn = UIButton(type: .system)
        getAutoDormancyBtn.setTitle("getAutoDormancy", for: .normal)
        getAutoDormancyBtn.tintColor = .white
        getAutoDormancyBtn.backgroundColor = .systemBlue
        getAutoDormancyBtn.frame = CGRect(x: 20, y: 400, width: 100, height: 50)
        getAutoDormancyBtn.addTarget(self, action: #selector(getAutoDormancy), for: .touchUpInside)
        view.addSubview(getAutoDormancyBtn)

        let setAutoDormancyBtn = UIButton(type: .system)
        setAutoDormancyBtn.setTitle("setAutoDormancy", for: .normal)
        setAutoDormancyBtn.tintColor = .white
        setAutoDormancyBtn.backgroundColor = .systemBlue
        setAutoDormancyBtn.frame = CGRect(x: 150, y: 400, width: 100, height: 50)
        setAutoDormancyBtn.addTarget(self, action: #selector(setAutoDormancy), for: .touchUpInside)
        view.addSubview(setAutoDormancyBtn)

        let setBasebandBtn = UIButton(type: .system)
        setBasebandBtn.setTitle("setEPCBaseband", for: .normal)
        setBasebandBtn.tintColor = .white
        setBasebandBtn.backgroundColor = .systemBlue
        setBasebandBtn.frame = CGRect(x: 270, y: 400, width: 100, height: 50)
        setBasebandBtn.addTarget(self, action: #selector(setBaseband), for: .touchUpInside)
        view.addSubview(setBasebandBtn)

        let getCapabilitiesBtn = UIButton(type: .system)
        getCapabilitiesBtn.setTitle("getCapabilities", for: .normal)
        getCapabilitiesBtn.tintColor = .white
        getCapabilitiesBtn.backgroundColor = .systemBlue
        getCapabilitiesBtn.frame = CGRect(x: 20, y: 470, width: 100, height: 50)
        getCapabilitiesBtn.addTarget(self, action: #selector(getCapabilities), for: .touchUpInside)
        view.addSubview(getCapabilitiesBtn)

        let getFreqRangeBtn = UIButton(type: .system)
        getFreqRangeBtn.setTitle("getFreqRange", for: .normal)
        getFreqRangeBtn.tintColor = .white
        getFreqRangeBtn.backgroundColor = .systemBlue
        getFreqRangeBtn.frame = CGRect(x: 150, y: 470, width: 100, height: 50)
        getFreqRangeBtn.addTarget(self, action: #selector(getFreqRange), for: .touchUpInside)
        view.addSubview(getFreqRangeBtn)

        let setFreqRangeBtn = UIButton(type: .system)
        setFreqRangeBtn.setTitle("setFreqRange", for: .normal)
        setFreqRangeBtn.tintColor = .white
        setFreqRangeBtn.backgroundColor = .systemBlue
        setFreqRangeBtn.frame = CGRect(x: 270, y: 470, width: 100, height: 50)
        setFreqRangeBtn.addTarget(self, action: #selector(setFreqRange), for: .touchUpInside)
        view.addSubview(setFreqRangeBtn)

        let getFrequencyBtn = UIButton(type: .system)
        getFrequencyBtn.setTitle("getFrequency", for: .normal)
        getFrequencyBtn.tintColor = .white
        getFrequencyBtn.backgroundColor = .systemBlue
        getFrequencyBtn.frame = CGRect(x: 20, y: 540, width: 100, height: 50)
        getFrequencyBtn.addTarget(self, action: #selector(getFrequency), for: .touchUpInside)
        view.addSubview(getFrequencyBtn)

        let setFrequencyBtn = UIButton(type: .system)
        setFrequencyBtn.setTitle("setFrequency", for: .normal)
        setFrequencyBtn.tintColor = .white
        setFrequencyBtn.backgroundColor = .systemBlue
        setFrequencyBtn.frame = CGRect(x: 150, y: 540, width: 100, height: 50)
        setFrequencyBtn.addTarget(self, action: #selector(setFrequency), for: .touchUpInside)
        view.addSubview(setFrequencyBtn)

        let lockEpcBtn = UIButton(type: .system)
        lockEpcBtn.setTitle("lockEpc", for: .normal)
        lockEpcBtn.tintColor = .white
        lockEpcBtn.backgroundColor = .systemBlue
        lockEpcBtn.frame = CGRect(x: 270, y: 540, width: 100, height: 50)
        lockEpcBtn.addTarget(self, action: #selector(lockEpc), for: .touchUpInside)
        view.addSubview(lockEpcBtn)

        let getTagLogBtn = UIButton(type: .system)
        getTagLogBtn.setTitle("getTagLog", for: .normal)
        getTagLogBtn.tintColor = .white
        getTagLogBtn.backgroundColor = .systemBlue
        getTagLogBtn.frame = CGRect(x: 20, y: 610, width: 100, height: 50)
        getTagLogBtn.addTarget(self, action: #selector(getTagLog), for: .touchUpInside)
        view.addSubview(getTagLogBtn)

        let setTagLogBtn = UIButton(type: .system)
        setTagLogBtn.setTitle("setTagLog", for: .normal)
        setTagLogBtn.tintColor = .white
        setTagLogBtn.backgroundColor = .systemBlue
        setTagLogBtn.frame = CGRect(x: 150, y: 610, width: 100, height: 50)
        setTagLogBtn.addTarget(self, action: #selector(setTagLog), for: .touchUpInside)
        view.addSubview(setTagLogBtn)

        let killEpcBtn = UIButton(type: .system)
        killEpcBtn.setTitle("killEpc", for: .normal)
        killEpcBtn.tintColor = .white
        killEpcBtn.backgroundColor = .systemBlue
        killEpcBtn.frame = CGRect(x: 270, y: 610, width: 100, height: 50)
        killEpcBtn.addTarget(self, action: #selector(killEpc), for: .touchUpInside)
        view.addSubview(killEpcBtn)

        textView = UITextView()
        textView.tintColor = .black
        textView.textColor = .black
        textView.backgroundColor = .white
        textView.frame = CGRect(x: 10, y: 700, width: 360, height: 120)
        textView.isScrollEnabled = true
        view.addSubview(textView)
    }

    @objc func searchBLE(_ button: UIButton) {
        openBluetoothAdapter()
        print("Search BLE Device...\n")
        DispatchQueue.main.async {
            self.textView.text.append("Search BLE Device...\n")
        }
    }

    @objc func closeBLE(_ button: UIButton) {
        if client.close() {
            print("Close BLE Success.")
            DispatchQueue.main.async {
                self.textView.text.append("Close BLE Success.\n")
            }
        }
    }

    @objc func connectBLE(_ button: UIButton) {
        if gbleDevice == nil {
            print("gbleDevice = nil")
            return
        }
        print("openclient name - " + (gbleDevice.gPeripheral.name ?? ""))
        if client.openBleClient(gBleDevice: gbleDevice) {
            client.onBLEConnect {
                name, code, msg in
                if code == 0 {
                    print("Connect Success.")
                    DispatchQueue.main.async {
                        self.textView.text.append("Connect Success.\n")
                    }
                    self.client.isPrint = false
                    self.client.sendDebugLog {
                        sendStr in
                        print(sendStr)
                    }
                    self.client.receiveDebugLog {
                        revStr in
                        print(revStr)
                    }
                    self.client.onTagEpcLog {
                        readerName, msg in
                        print("\(msg.toString())")
                        DispatchQueue.main.async {
                            self.textView.text.append("EPC = \(msg.epc) TID = \(msg.tid) ReaderName = \(readerName)\n")
                        }
                    }
                    self.client.onTagEpcOver {
                        readerName, _ in
                        print("TagEpcOver ReaderName = \(readerName)")
                        DispatchQueue.main.async {
                            self.textView.text.append("TagEpcOver ReaderName = \(readerName) \n")
                        }
                    }
                } else {
                    print("\(name) - Connect Failure,errMsg=\(msg)")
                    DispatchQueue.main.async {
                        self.textView.text.append("\(name) - Connect Failure,errMsg=\(msg) \n")
                    }
                }
            }
            client.onBLEDisconnect {
                name, errMsg in
                DispatchQueue.main.async {
                    print("\(name) - Disconnected, errMsg=\(errMsg)")
                    if self.client.close() {
                        print("\(name) - Closed")
                    }
                    self.textView.text.append("BLE Connection Disconnected.\n")
                }
            }
            // stop search ble device
            gbleManager.stopBluetoothDevicesDiscovery()
        }
    }

    @objc func readEpc(_ button: UIButton) {
        let msg = MsgBaseInventoryEpc()
        msg.antennaEnable = EnumG.AntennaNo_1
        msg.inventoryMode = EnumG.InventoryMode_Inventory

//        let filter = ParamEpcFilter()
//        filter.area = EnumG.ParamFilterArea_TID
//        filter.bitStart = 0
//        filter.hexData = "E2003412012E1B0000818E0C"
//        filter.bitLength = filter.hexData.count * 4
//        msg.filter = filter

//        let readTidParam = ParamEpcReadTid()
//        readTidParam.mode = EnumG.ParamTidMode_Auto
//        readTidParam.len = 6
//        msg.readTid = readTidParam

//        let readReserved = ParamEpcReadReserved()
//        readReserved.start = 0
//        readReserved.len = 4
//        msg.readReserved = readReserved

        client.sendAsyncMsg(msg: msg, callback: {
            _ in
            if msg.getRtCode() == 0 {
                print("read success")
                DispatchQueue.main.async {
                    self.textView.text.append("read success.\n")
                }
            } else {
                print("read failure - " + msg.getRtMsg())
                DispatchQueue.main.async {
                    self.textView.text.append("read failure - \(msg.getRtMsg())\n")
                }
            }
        }, timeout: 3000)
    }

    @objc func writeEpc(_ button: UIButton) {
        let msg = MsgBaseWriteEpc()
        msg.antennaEnable = EnumG.AntennaNo_1
        msg.area = EnumG.WriteArea_Epc
        msg.start = 2
        msg.hexWriteData = "1234567812345678"

        let filter = ParamEpcFilter()
        filter.area = EnumG.ParamFilterArea_TID
        filter.bitStart = 0
        filter.hexData = "E2003412012E1B0000818E0C"
        filter.bitLength = filter.hexData.count * 4
        msg.filter = filter

        msg.hexPassword = "ABCDEF09"

        client.sendAsyncMsg(msg: msg, callback: {
            _ in
            if msg.getRtCode() == 0 {
                print("write success")
                DispatchQueue.main.async {
                    self.textView.text.append("write success.\n")
                }
            } else {
                print("write failure - \(msg.getRtMsg())\n")
                DispatchQueue.main.async {
                    self.textView.text.append("write failure - \(msg.getRtMsg())\n")
                }
            }
        }, timeout: 3000)
    }

    @objc func lockEpc(_ button: UIButton) {
        let msg = MsgBaseLockEpc()
        msg.antennaEnable = EnumG.AntennaNo_1
        msg.area = EnumG.LockArea_Epc
        msg.mode = EnumG.LockMode_Unlock

        let filter = ParamEpcFilter()
        filter.area = EnumG.ParamFilterArea_TID
        filter.bitStart = 0
        filter.hexData = "E2003412012E1B0000818E0C"
        filter.bitLength = filter.hexData.count * 4
        msg.filter = filter

        msg.hexPassword = "ABCDEF09"

        client.sendAsyncMsg(msg: msg, callback: {
            _ in
            if msg.getRtCode() == 0 {
                print("lock success")
                DispatchQueue.main.async {
                    self.textView.text.append("lock success.\n")
                }
            } else {
                print("lock failure - \(msg.getRtMsg())\n")
                DispatchQueue.main.async {
                    self.textView.text.append("lock failure - \(msg.getRtMsg())\n")
                }
            }
        }, timeout: 3000)
    }

    @objc func killEpc(_ button: UIButton) {
        let msg = MsgBaseKillEpc()
        msg.antennaEnable = EnumG.AntennaNo_1

        let filter = ParamEpcFilter()
        filter.area = EnumG.ParamFilterArea_TID
        filter.bitStart = 0
        filter.hexData = "E2003412012E1B0000818E0C"
        filter.bitLength = filter.hexData.count * 4
        msg.filter = filter

        msg.hexPassword = "12345678"

        client.sendAsyncMsg(msg: msg, callback: {
            _ in
            if msg.getRtCode() == 0 {
                print("kill success")
                DispatchQueue.main.async {
                    self.textView.text.append("kill success.\n")
                }
            } else {
                print("kill failure - \(msg.getRtMsg())\n")
                DispatchQueue.main.async {
                    self.textView.text.append("kill failure - \(msg.getRtMsg())\n")
                }
            }
        }, timeout: 3000)
    }

    @objc func stop(_ button: UIButton) {
        let stop = MsgBaseStop()
        client.sendAsyncMsg(msg: stop, callback: {
            _ in
            if stop.getRtCode() == 0 {
                print("stop success")
                DispatchQueue.main.async {
                    self.textView.text.append("stop success.\n")
                }
            } else {
                print("stop failure - \(stop.getRtMsg())")
                DispatchQueue.main.async {
                    self.textView.text.append("stop failure - \(stop.getRtMsg())\n")
                }
            }
        }, timeout: 3000)
    }

    @objc func getVer(_ button: UIButton) {
        let getReaderInfo = MsgAppGetReaderInfo()
        client.sendAsyncMsg(msg: getReaderInfo, callback: {
            _ in
            if getReaderInfo.getRtCode() == 0 {
                print("GetReaderInfo success")
                DispatchQueue.main.async {
                    self.textView.text.append("GetReaderInfo Success. \(getReaderInfo.toString())\n")
                }
            } else {
                print("GetReaderInfo failure - " + getReaderInfo.getRtMsg())
            }
        }, timeout: 3000)

        let getBaseVersion = MsgAppGetBaseVersion()
        client.sendAsyncMsg(msg: getBaseVersion, callback: {
            _ in
            if getBaseVersion.getRtCode() == 0 {
                print("GetBaseVersion success")
                print("baseversion.baseVersion - \(getBaseVersion.baseVersion)")
                DispatchQueue.main.async {
                    self.textView.text.append("GetBaseVersion success. \(getBaseVersion.toString())\n")
                }
            } else {
                print("GetBaseVersion failure - " + getBaseVersion.getRtMsg())
                DispatchQueue.main.async {
                    DispatchQueue.main.async {
                        self.textView.text.append("GetBaseVersion failure -  \(getBaseVersion.getRtMsg())\n")
                    }
                }
            }
        }, timeout: 3000)
    }

    @objc func getPower(_ button: UIButton) {
        let getPower = MsgBaseGetPower()
        client.sendAsyncMsg(msg: getPower, callback: {
            _ in
            if getPower.getRtCode() == 0 {
                print("Get Power Success.")
                let dicPower = getPower.dicPower
                for i in dicPower.keys {
                    print("ant=\(i) power= \(dicPower[i] ?? 0)")
                    DispatchQueue.main.async {
                        self.textView.text.append("ant=\(i) power=\(dicPower[i] ?? 0) \n")
                    }
                }

            } else {
                print("GetBaseVersion failure - \(getPower.getRtMsg())")
                DispatchQueue.main.async {
                    self.textView.text.append("GetBaseVersion failure - \(getPower.getRtMsg())\n")
                }
            }
        }, timeout: 3000)
    }

    @objc func setPower(_ button: UIButton) {
        let setPower = MsgBaseSetPower()
        setPower.dicPower[1] = 15
        client.sendAsyncMsg(msg: setPower, callback: {
            _ in
            if setPower.getRtCode() == 0 {
                print("Set Power Success")
                DispatchQueue.main.async {
                    self.textView.text.append("Set Power Success.\n")
                }
            } else {
                print("Set Power Failure - \(setPower.getRtMsg())")
                DispatchQueue.main.async {
                    self.textView.text.append("Set Power Failure - \(setPower.getRtMsg())\n")
                }
            }
        }, timeout: 3000)
    }

    @objc func restoreDefault(_ button: UIButton) {
        let msg = MsgAppRestoreDefault()
        client.sendAsyncMsg(msg: msg, callback: {
            _ in
            if msg.getRtCode() == 0 {
                print("RestoreDefault Success")
                DispatchQueue.main.async {
                    self.textView.text.append("RestoreDefault Success.\n")
                }
            } else {
                print("RestoreDefault Failure - \(msg.getRtMsg())")
                DispatchQueue.main.async {
                    self.textView.text.append("RestoreDefault Failure - \(msg.getRtMsg())\n")
                }
            }
        }, timeout: 3000)
    }

    @objc func getGpiTrigger(_ button: UIButton) {
        let msg = MsgAppGetGpiTrigger()
        msg.gpiPort = 0
        client.sendAsyncMsg(msg: msg, callback: {
            _ in
            if msg.getRtCode() == 0 {
                print("GetGpiTrigger Success")
                DispatchQueue.main.async {
                    self.textView.text.append("GetGpiTrigger Success.\n")
                    self.textView.text.append("\(msg.toString())\n")
                }
            } else {
                print("GetGpiTrigger Failure - \(msg.getRtMsg())")
                DispatchQueue.main.async {
                    self.textView.text.append("GetGpiTrigger Failure - \(msg.getRtMsg())\n")
                }
            }
        }, timeout: 3000)
    }

    @objc func setGpiTrigger(_ button: UIButton) {
        let msg = MsgAppSetGpiTrigger()
        msg.gpiPort = 0 // GPI1
        msg.triggerStart = 2 // high
        msg.hexTriggerCommand = "0001021000080000000101020006"
        msg.triggerOver = 0 // 0,none
        msg.overDelayTime = 6000 // 10ms
        msg.levelUploadSwitch = 1
        msg.antiShakeTime = 50 // ms
        client.sendAsyncMsg(msg: msg, callback: {
            _ in
            if msg.getRtCode() == 0 {
                print("SetGpiTrigger Success")
                DispatchQueue.main.async {
                    self.textView.text.append("SetGpiTrigger Success.\n")
                }
            } else {
                print("SetGpiTrigger Failure - \(msg.getRtMsg())")
                DispatchQueue.main.async {
                    self.textView.text.append("SetGpiTrigger Failure - \(msg.getRtMsg())\n")
                }
            }
        }, timeout: 3000)
    }

    @objc func getUsbKeyboard(_ button: UIButton) {
        let msg = MsgAppUsbKeyboard()
        msg.operationType = 0 // get
        client.sendAsyncMsg(msg: msg, callback: {
            _ in
            if msg.getRtCode() == 0 {
                print("getUsbKeyboard Success")
                print(msg.toString())
                DispatchQueue.main.async {
                    self.textView.text.append("getUsbKeyboard Success.\n")
                    self.textView.text.append(msg.toString())
                }
            } else {
                print("getUsbKeyboard Failure - \(msg.getRtMsg())")
                DispatchQueue.main.async {
                    self.textView.text.append("getUsbKeyboard Failure - \(msg.getRtMsg())\n")
                }
            }
        }, timeout: 3000)
    }

    @objc func setUsbKeyboard(_ button: UIButton) {
        let msg = MsgAppUsbKeyboard()
        msg.operationType = 1 // set
        msg.reportType = 1
        msg.encodingMethod = 0
        msg.prefix = "09"
        msg.suffix = "0D0A"

        client.sendAsyncMsg(msg: msg, callback: {
            _ in
            if msg.getRtCode() == 0 {
                print("setUsbKeyboard Success")
                DispatchQueue.main.async {
                    self.textView.text.append("setUsbKeyboard Success.\n")
                    self.textView.text.append(msg.toString())
                }
            } else {
                print("setUsbKeyboard Failure - \(msg.getRtMsg())")
                DispatchQueue.main.async {
                    self.textView.text.append("setUsbKeyboard Failure - \(msg.getRtMsg())\n")
                }
            }
        }, timeout: 3000)
    }

    @objc func getAutoDormancy(_ button: UIButton) {
        let msg = MsgBaseGetAutoDormancy()

        client.sendAsyncMsg(msg: msg, callback: {
            _ in
            if msg.getRtCode() == 0 {
                print("GetAutoDormancy Success")
                DispatchQueue.main.async {
                    self.textView.text.append("GetAutoDormancy Success.\n")
                    self.textView.text.append("\(msg.toString())\n")
                }
            } else {
                print("GetAutoDormancy Failure - \(msg.getRtMsg())")
                DispatchQueue.main.async {
                    self.textView.text.append("GetAutoDormancy Failure - \(msg.getRtMsg())\n")
                }
            }
        }, timeout: 3000)
    }

    @objc func setAutoDormancy(_ button: UIButton) {
        let msg = MsgBaseSetAutoDormancy()
        msg.onOff = 1
        msg.freeTime = 1000
        client.sendAsyncMsg(msg: msg, callback: {
            _ in
            if msg.getRtCode() == 0 {
                print("SetAutoDormancy Success")
                DispatchQueue.main.async {
                    self.textView.text.append("SetAutoDormancy Success.\n")
                }
            } else {
                print("SetAutoDormancy Failure - \(msg.getRtMsg())")
                DispatchQueue.main.async {
                    self.textView.text.append("SetAutoDormancy Failure - \(msg.getRtMsg())\n")
                }
            }
        }, timeout: 3000)
    }

    @objc func getBaseband(_ button: UIButton) {
        let msg = MsgBaseGetEpcBaseband()

        client.sendAsyncMsg(msg: msg, callback: {
            _ in
            if msg.getRtCode() == 0 {
                print("GetBaseband Success")
                DispatchQueue.main.async {
                    self.textView.text.append("GetBaseband Success.\n")
                    self.textView.text.append("\(msg.toString())\n")
                }
            } else {
                print("GetBaseband Failure - \(msg.getRtMsg())")
                DispatchQueue.main.async {
                    self.textView.text.append("GetBaseband Failure - \(msg.getRtMsg())\n")
                }
            }
        }, timeout: 3000)
    }

    @objc func setBaseband(_ button: UIButton) {
        let msg = MsgBaseSetEpcBaseband()
        msg.baseSpeed = 1
        msg.session = 0
        msg.qValue = 4
        msg.inventoryFlag = 0
        client.sendAsyncMsg(msg: msg, callback: {
            _ in
            if msg.getRtCode() == 0 {
                print("SetBaseband Success")
                DispatchQueue.main.async {
                    self.textView.text.append("SetBaseband Success.\n")
                }
            } else {
                print("SetBaseband Failure - \(msg.getRtMsg())")
                DispatchQueue.main.async {
                    self.textView.text.append("SetBaseband Failure - \(msg.getRtMsg())\n")
                }
            }
        }, timeout: 3000)
    }

    @objc func getCapabilities(_ button: UIButton) {
        let msg = MsgBaseGetCapabilities()

        client.sendAsyncMsg(msg: msg, callback: {
            _ in
            if msg.getRtCode() == 0 {
                print("GetCapabilities Success")
                DispatchQueue.main.async {
                    self.textView.text.append("GetCapabilities Success.\n")
                    self.textView.text.append("\(msg.toString())\n")
                }
            } else {
                print("GetCapabilities Failure - \(msg.getRtMsg())")
                DispatchQueue.main.async {
                    self.textView.text.append("GetCapabilities Failure - \(msg.getRtMsg())\n")
                }
            }
        }, timeout: 3000)
    }

    @objc func getFreqRange(_ button: UIButton) {
        let msg = MsgBaseGetFreqRange()

        client.sendAsyncMsg(msg: msg, callback: {
            _ in
            if msg.getRtCode() == 0 {
                print("GetFreqRange Success")
                DispatchQueue.main.async {
                    self.textView.text.append("GetFreqRange Success.\n")
                    self.textView.text.append("\(msg.toString())\n")
                }
            } else {
                print("GetFreqRange Failure - \(msg.getRtMsg())")
                DispatchQueue.main.async {
                    self.textView.text.append("GetFreqRange Failure - \(msg.getRtMsg())\n")
                }
            }
        }, timeout: 3000)
    }

    @objc func setFreqRange(_ button: UIButton) {
        let msg = MsgBaseSetFreqRange()
        msg.freqRangeIndex = 1
//        msg.powerDownSave = 0
        client.sendAsyncMsg(msg: msg, callback: {
            _ in
            if msg.getRtCode() == 0 {
                print("SetFreqRange Success")
                DispatchQueue.main.async {
                    self.textView.text.append("SetFreqRange Success.\n")
                }
            } else {
                print("SetFreqRange Failure - \(msg.getRtMsg())")
                DispatchQueue.main.async {
                    self.textView.text.append("SetFreqRange Failure - \(msg.getRtMsg())\n")
                }
            }
        }, timeout: 3000)
    }

    @objc func getFrequency(_ button: UIButton) {
        let msg = MsgBaseGetFrequency()

        client.sendAsyncMsg(msg: msg, callback: {
            _ in
            if msg.getRtCode() == 0 {
                print("GetFrequency Success")
                DispatchQueue.main.async {
                    self.textView.text.append("GetFrequency Success.\n")
                    self.textView.text.append("\(msg.toString())\n")
                }
            } else {
                print("GetFrequency Failure - \(msg.getRtMsg())")
                DispatchQueue.main.async {
                    self.textView.text.append("GetFrequency Failure - \(msg.getRtMsg())\n")
                }
            }
        }, timeout: 3000)
    }

    @objc func setFrequency(_ button: UIButton) {
        let msg = MsgBaseSetFrequency()
        msg.automatically = false
        msg.freqIndexArray.append(0)
        msg.freqIndexArray.append(1)
        msg.freqIndexArray.append(2)
        msg.freqIndexArray.append(3)
        msg.freqIndexArray.append(4)

        client.sendAsyncMsg(msg: msg, callback: {
            _ in
            if msg.getRtCode() == 0 {
                print("SetFrequency Success")
                DispatchQueue.main.async {
                    self.textView.text.append("SetFrequency Success.\n")
                }
            } else {
                print("SetFrequency Failure - \(msg.getRtMsg())")
                DispatchQueue.main.async {
                    self.textView.text.append("SetFrequency Failure - \(msg.getRtMsg())\n")
                }
            }
        }, timeout: 3000)
    }

    @objc func getTagLog(_ button: UIButton) {
        let msg = MsgBaseGetTagLog()

        client.sendAsyncMsg(msg: msg, callback: {
            _ in
            if msg.getRtCode() == 0 {
                print("GetTagLog Success")
                DispatchQueue.main.async {
                    self.textView.text.append("GetTagLog Success.\n")
                    self.textView.text.append("\(msg.toString())\n")
                }
            } else {
                print("GetTagLog Failure - \(msg.getRtMsg())")
                DispatchQueue.main.async {
                    self.textView.text.append("GetTagLog Failure - \(msg.getRtMsg())\n")
                }
            }
        }, timeout: 3000)
    }

    @objc func setTagLog(_ button: UIButton) {
        let msg = MsgBaseSetTagLog()
        msg.repeatedTime = 100
        msg.rssiTV = 20
//        msg.powerDownSave = 0

        client.sendAsyncMsg(msg: msg, callback: {
            _ in
            if msg.getRtCode() == 0 {
                print("SetTagLog Success")
                DispatchQueue.main.async {
                    self.textView.text.append("SetTagLog Success.\n")
                }
            } else {
                print("SetTagLog Failure - \(msg.getRtMsg())")
                DispatchQueue.main.async {
                    self.textView.text.append("SetTagLog Failure - \(msg.getRtMsg())\n")
                }
            }
        }, timeout: 3000)
    }

    // MARK: - ble

    func openBluetoothAdapter() {
        gbleManager.onBluetoothAdapterStateChange { ok, _, errMsg in
            if ok {
                self.startScan()
            } else {
                if errMsg == "poweredOff" {
                    print("Please turn on the system Bluetooth switch")
                    DispatchQueue.main.async {
                        self.textView.text.append("Please turn on the system Bluetooth switch\n")
                    }
                } else if errMsg == "unauthorized" {
                    print("Please turn on the app's Bluetooth permission")
                    DispatchQueue.main.async {
                        self.textView.text.append("Please turn on the app's Bluetooth permission\n")
                    }
                } else {
                    print("Bluetooth adapter error, errMsg=" + errMsg)
                    DispatchQueue.main.async {
                        self.textView.text.append("Bluetooth adapter error, errMsg=\(errMsg)\n")
                    }
                }
            }
        }
        gbleManager.openBluetoothAdapter()
    }

    func startScan() {
        gbleManager.onBluetoothDevicePeripheral {
            peripheral, rssi in
            print("name - " + (peripheral.name ?? ""))
            print("id - " + peripheral.identifier.uuidString)
            print("rssi - \(rssi)")
            DispatchQueue.main.async {
                self.textView.text.append("name -  \(peripheral.name ?? "")\n")
                self.textView.text.append("id - \(peripheral.identifier.uuidString)\n")
            }
            if peripheral.name == "NA700FFFF242401A0003" { // MR1000000240726A0001 MR1000000240701A0001 NA700FFFF242401A0003
                self.peripheral = peripheral
                self.gbleDevice = GBleDevice(gble: self.gbleManager, gPeripheral: peripheral)
                return
            }
        }
        gbleManager.startBluetoothDevicesDiscovery()
    }
}
