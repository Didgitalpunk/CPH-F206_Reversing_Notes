from uhf.reader import *
from time import *

if __name__ == '__main__':
    g_client = GClient()
    # if g_client.openSerial(("COM7", 115200)):
    if g_client.openTcp(("192.168.1.168", 8160)):
        # 写入内容
        data = "1234"
        # 返回pc值+内容，未凑足以字为单位长度补全
        value = getEpcData(data)
        print(value)
        # 1号天线 写epc区 起始地址1(0是crc不可写)
        msg = MsgBaseWriteEpc(antennaEnable=1, area=EnumG.WriteArea_Epc.value, start=1, hexWriteData=value)

        # 匹配指定tid标签写epc
        tid = "E200F3A54450363539320009"
        epc_filter = ParamEpcFilter(area=EnumG.ParamFilterArea_TID.value, bitStart=0,
                                    hexData=tid)
        msg.filter = epc_filter

        if g_client.sendSynMsg(msg) == 0:
            print(msg.rtMsg)
        else:
            print(msg.rtMsg)

        # 断开连接
        g_client.close()
