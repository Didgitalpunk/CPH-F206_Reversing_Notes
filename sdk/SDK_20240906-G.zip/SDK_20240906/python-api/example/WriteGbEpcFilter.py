from uhf.reader import *
from time import *

if __name__ == '__main__':
    g_client = GClient()
    # if g_client.openSerial(("COM7", 115200)):
    if g_client.openTcp(("192.168.1.168", 8160)):
        # 写入内容
        data = "1234"
        # 返回pc值+内容，未凑足以字为单位长度补全
        value = getGbData(data)
        print(value)
        # 1号天线 写epc区 起始地址0 0x10:标签编码区 | 0x20:标签安全区 | 0x30~0x3F:用户子区0~15
        msg = MsgBaseWriteGb(antennaEnable=1, area=0x10, start=0, hexWriteData=value)

        # 匹配指定tid标签写epc
        tid = "E200F3A54450363539320009"
        epc_filter = ParamEpcFilter(area=0x00, bitStart=0,
                                    hexData=tid)
        msg.filter = epc_filter

        if g_client.sendSynMsg(msg) == 0:
            print(msg.rtMsg)

        # 断开连接
        g_client.close()
