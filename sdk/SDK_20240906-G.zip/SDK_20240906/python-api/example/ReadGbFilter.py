from uhf.reader import *
from time import *


def receivedGb(gbInfo: LogBaseGbInfo):
    if gbInfo.result == 0:
        print(gbInfo.epc,gbInfo.tid)


def receivedGbOver(gbOver: LogBaseGbOver):
    print("LogBaseGbOver")


if __name__ == '__main__':
    g_client = GClient()
    # if g_client.openSerial(("COM7", 115200)):
    if g_client.openTcp(("192.168.1.168", 8160)):
        # 订阅标签回调
        g_client.callGbInfo = receivedGb
        g_client.callGbOver = receivedGbOver

        # 读epc
        msg = MsgBaseInventoryGb(antennaEnable=EnumG.AntennaNo_1.value,
                                 inventoryMode=EnumG.InventoryMode_Inventory.value)

        # 匹配TID读 E280110520007993A8F708A8 可选参数
        # epc_filter = ParamEpcFilter(area=0x00, bitStart=0, hexData="E280110520007993A8F708A8")
        # msg.filter = epc_filter

        # 读TID 默认只读EPC 可选参数
        tid = ParamEpcReadTid(mode=EnumG.ParamTidMode_Auto.value, dataLen=6)
        msg.readTid = tid

        # 读UserData 可选参数 用户子区1 起始地址4 读取长度4
        # userData = ParamGbReadUserData(childArea=0x30, start=4, dataLen=4)
        # msg.readUserData = userData

        if g_client.sendSynMsg(msg) == 0:
            print(msg.rtMsg)

        # 5s后执行停止盘点以及关闭连接
        sleep(5)

        stop = MsgBaseStop()
        if g_client.sendSynMsg(stop) == 0:
            print(stop.rtMsg)

        g_client.close()
