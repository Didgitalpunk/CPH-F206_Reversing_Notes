from uhf.reader import *
from time import *

if __name__ == '__main__':
    g_client = GClient()
    # if g_client.openSerial(("COM7", 115200)):
    if g_client.openTcp(("192.168.1.168", 8160)):
        # 写入内容
        data = "1234"
        # 返回pc值+内容，未凑足以字为单位长度补全
        value = getEpcData(data)
        print(value)
        # 1号天线 写epc区 起始地址1(0是crc不可写)
        epc = MsgBaseWriteEpc(antennaEnable=1, area=EnumG.WriteArea_Epc.value, start=1, hexWriteData=value)
        if g_client.sendSynMsg(epc) == 0:
            print(epc.rtMsg)

        # 断开连接
        g_client.close()
