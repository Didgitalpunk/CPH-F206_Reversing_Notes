from uhf.reader import *
from time import *

if __name__ == '__main__':
    g_client = GClient()
    # if g_client.openSerial(("COM7", 115200)):
    if g_client.openTcp(("192.168.1.168", 8160)):
        # 写入内容
        data = "1234"
        # 返回pc值+内容，未凑足以字为单位长度补全
        value = getGbData(data)
        print(value)
        # 1号天线 写epc区 起始地址0  0x10:标签编码区 | 0x20:标签安全区 | 0x30~0x3F:用户子区0~15
        epc = MsgBaseWriteGb(antennaEnable=1, area=0x10, start=0, hexWriteData=value)
        if g_client.sendSynMsg(epc) == 0:
            print(epc.rtMsg)

        # 断开连接
        g_client.close()
