from uhf.reader import *
from time import *

if __name__ == '__main__':
    g_client = GClient()
    # if g_client.openSerial(("COM7", 115200)):
    if g_client.openTcp(("192.168.1.168", 8160)):
        # 写入内容
        data = "1234"
        # 0x10:标签编码区 | 0x20:标签安全区 | 0x30~0x3F:用户子区0~15
        # 1号天线 写epc区 起始地址4
        epc = MsgBaseWriteGb(antennaEnable=1, area=0x30, start=4, hexWriteData=data)
        if g_client.sendSynMsg(epc) == 0:
            print(epc.rtMsg)

        # 断开连接
        g_client.close()
