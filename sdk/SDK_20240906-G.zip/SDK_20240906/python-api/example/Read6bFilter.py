from uhf.reader import *
from time import *


def received6b(info: LogBase6bInfo):
    if info.result == 0:
        print(info.tid ,info.userData)


def received6bOver(over: LogBase6bOver):
    print("LogBase6bOver")


if __name__ == '__main__':
    g_client = GClient()
    # if g_client.openSerial(("COM7", 115200)):
    if g_client.openTcp(("192.168.1.168", 8160)):
        # 订阅标签回调
        g_client.call6bInfo = received6b
        g_client.call6bOver = received6bOver

        # 读6b tid
        msg = MsgBaseInventory6b(antennaEnable=EnumG.AntennaNo_1.value,
                                 inventoryMode=EnumG.InventoryMode_Inventory.value,
                                 area=EnumG.ReadMode6b_TidAndUserData.value)
        # 读用户区 可选参数
        userData = Param6bReadUserData(start=0, dataLen=10)  # byte
        msg.readUserData = userData

        # 匹配TID 可选参数
        # msg.hexMatchTid("E0040000B6B3E808")

        if g_client.sendSynMsg(msg) == 0:
            print(msg.rtMsg)
        else:
            print(msg.rtMsg)

        # 5s后执行停止盘点以及关闭连接
        sleep(5)

        stop = MsgBaseStop()
        if g_client.sendSynMsg(stop) == 0:
            print(stop.rtMsg)

        g_client.close()
