from uhf.reader import *
from time import *


def receivedGb(gbInfo: LogBaseGbInfo):
    if gbInfo.result == 0:
        print(gbInfo.epc)


def receivedGbOver(gbOver: LogBaseGbOver):
    print("LogBaseGbOver")


if __name__ == '__main__':
    g_client = GClient()
    # if g_client.openSerial(("COM7", 115200)):
    if g_client.openTcp(("192.168.1.168", 8160)):
        # 订阅标签回调
        g_client.callGbInfo = receivedGb
        g_client.callGbOver = receivedGbOver

        # 读epc
        msg = MsgBaseInventoryGb(antennaEnable=EnumG.AntennaNo_1.value,
                                 inventoryMode=EnumG.InventoryMode_Inventory.value)
        if g_client.sendSynMsg(msg) == 0:
            print(msg.rtMsg)

        # 5s后执行停止盘点以及关闭连接
        sleep(5)

        stop = MsgBaseStop()
        if g_client.sendSynMsg(stop) == 0:
            print(stop.rtMsg)

        g_client.close()
