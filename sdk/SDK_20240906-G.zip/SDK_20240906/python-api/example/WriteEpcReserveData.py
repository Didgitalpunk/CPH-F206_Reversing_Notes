from uhf.reader import *
from time import *

if __name__ == '__main__':
    g_client = GClient()
    # if g_client.openSerial(("COM7", 115200)):
    if g_client.openTcp(("192.168.1.168", 8160)):
        # 写入内容
        data = "12345678"
        # 1号天线 写保留区 起始地址2
        # 前4个字节表示销毁密码 后四个字节表示访问密码
        epc = MsgBaseWriteEpc(antennaEnable=1, area=EnumG.WriteArea_Reserved.value, start=2, hexWriteData=data)
        if g_client.sendSynMsg(epc) == 0:
            print(epc.rtMsg)

        # 断开连接
        g_client.close()
