#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <tchar.h> 
#include "delegate.h"
#include "message.h"
#include "GClient.h"

#pragma comment(lib, "GReader")

GClient* gclient;


int main()
{
	gclient = OpenRS232("COM12:115200", 3);

	if (gclient == NULL) {
		printf("Failed to connection.\n");
		return 0;
	}
	else {
		printf("Succeed to connection.\n");
	}

	MsgBaseWriteGB msg;
	memset(&msg, 0, sizeof(msg));

	msg.AntennaEnable = AntennaNo_1;
	msg.Area = 0x10;//��ǩ������

	msg.Start = 0x01;
	msg.DataLength = 2;
	memset(msg.DataContent, 0, 4);
	strcpy(msg.DataContent, "5678");

	msg.Filter.Area = 0x00;//��ǩ��Ϣ��
	msg.Filter.BitStart = 0;
	memset(msg.Filter.HexData, 0, 24);
	strcpy(msg.Filter.HexData, "E0832001200000000A951423");
	msg.Filter.BitLen = strlen(msg.Filter.HexData) * 4;


	SendSynMsg(gclient, EMESS_BaseWriteGb, &msg);
	if (msg.rst.RtCode != 0)
	{
		printf("failed to MsgBaseWriteGB: %s \n", msg.rst.RtMsg);
	}
	else {
		printf("Success to MsgBaseWriteGB.\n");
	}
	
	return 0;

}
