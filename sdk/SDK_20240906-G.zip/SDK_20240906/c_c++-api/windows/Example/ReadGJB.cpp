#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <tchar.h> 
#include "delegate.h"
#include "message.h"
#include "GClient.h"

#pragma comment(lib, "GReader")

GClient* gclient;
int count = 0;

void TagGjbLog(char* readerName, LogBaseGjbInfo msg)
{
	if (msg.Result == 0) {
		printf("EPC: %s\n", msg.Epc);
		printf("TID: %s\n", msg.Tid);
		printf("USER: %s\n", msg.Userdata);
		printf("RSSI: %d\n", msg.Rssi);
		count++;
	}
}

void TagGjbOver(char* readerName, LogBaseGjbOver msg)
{
	printf("TagGjbOver \n");
	printf("count = %d\n", count);
}


int main()
{
	gclient = OpenRS232("COM12:115200", 3);

	if (gclient == NULL) {
		printf("Failed to Connect.\n");
		return 0;
	}
	else {
		printf("Connect.\n");
		gclient->isPrint = true;
	}

	RegCallBack(gclient, ETagGjbLog, (void*)TagGjbLog);
	RegCallBack(gclient, ETagGjbOver, (void*)TagGjbOver);

	MsgBaseStop stop;
	memset(&stop, 0, sizeof(stop));
	SendSynMsg(gclient, EMESS_BaseStop, &stop);
	if (stop.rst.RtCode != 0) {
		printf("[MsgBaseStop] - Fail. %s. \n", stop.rst.RtMsg);
		return 0;
	}
	else
	{
		printf("[MsgBaseStop] - Success. \n");
	}

	Sleep(500);

	MsgBaseInventoryGJB msg;
	memset(&msg, 0, sizeof(msg));

	msg.AntennaEnable = AntennaNo_1;

	msg.InventoryMode = eInventory;

	msg.Filter.Area = 0x00;
	msg.Filter.BitStart = 0;
	memset(msg.Filter.HexData, 0, 24);
	strcpy(msg.Filter.HexData, "A0900000000F46DEA7100000");
	msg.Filter.BitLen = strlen(msg.Filter.HexData) * 4;

	msg.ReadTid.Mode = 0;
	msg.ReadTid.Len = 6;

	msg.ReadUserdata.Start = 4;
	msg.ReadUserdata.Len = 1;

	SendSynMsg(gclient, EMESS_BaseInventoryGjb, &msg);
	if (msg.rst.RtCode != 0)
	{
		printf("failed to MsgBaseInventoryGJB: %s \n", msg.rst.RtMsg);
	}
	else
	{
		printf("Success to MsgBaseInventoryGJB.\n");
	}

	Sleep(5000);

	memset(&stop, 0, sizeof(stop));
	SendSynMsg(gclient, EMESS_BaseStop, &stop);
	if (stop.rst.RtCode != 0) {
		printf("failed to MsgBaseStop: %s \n", stop.rst.RtMsg);
		return 0;
	}
	else
	{
		printf("Success to MsgBaseStop. \n");
	}

	Sleep(500);

	return 0;

}
