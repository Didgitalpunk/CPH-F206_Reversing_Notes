#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <tchar.h> 
#include "delegate.h"
#include "message.h"
#include "GClient.h"

#pragma comment(lib, "GReader")

GClient* gclient;

char* HexToString(char* buf, int len)  //�������ͷ��ڴ�
{
	char* result = new  char[len * 2 + 1];
	memset(result, 0, len * 2 + 1);
	char* pAscii = result;

	unsigned char Nibble[2];
	for (int i = 0; i < len; i++) {
		Nibble[0] = (buf[i] & 0xF0) >> 4;
		Nibble[1] = buf[i] & 0x0F;
		for (int j = 0; j < 2; j++) {
			if (Nibble[j] < 10) {
				Nibble[j] += 0x30;
			}
			else {
				if (Nibble[j] < 16) {
					Nibble[j] = Nibble[j] - 10 + 'A';
				}
			}
			*pAscii++ = Nibble[j];
		}
	}

	return result;

}

int main()
{
	gclient = OpenRS232("COM12:115200", 3);

	if (gclient == NULL) {
		printf("failed to connection.\n");
		return 0;
	}
	else {
		printf("succeed to connection.\n");
	}

	MsgBaseWriteEpc msg;
	memset(&msg, 0, sizeof(msg));

	msg.AntennaEnable = AntennaNo_1;
	msg.Area = 1;	// 0����������1��EPC ����2��TID ����3���û�������
	msg.Start = 1;
	int dataLen = 24;
	char data[25] = "C2254B002000CAAAA3E6FFC5";

	unsigned short pclen = 0;
	pclen = (dataLen / 4) << 11;  //�ֳ�������11λ
	char pc[2] = { 0 };
	pc[0] = (pclen >> 8) & 0xFF;  //PCֵ,ǰ5bit����д�������ֳ���
	pc[1] = pclen & 0xFF;

	char* temp = HexToString(pc, 2);
	char writeData[29] = { 0 };
	memcpy(writeData, temp, 4);
	memcpy(writeData + 4, data, 25);
	delete[] temp;

	memset(msg.StrHexWriteData, 0, dataLen + 1);
	memcpy(msg.StrHexWriteData, writeData, sizeof(writeData));

	//ѡ��д��ƥ�����
	msg.Filter.Area = 2;
	msg.Filter.BitStart = 0;
	memset(msg.Filter.HexData, 0, 25);
	strcpy(msg.Filter.HexData, "E2003412012F030000D9944D");
	msg.Filter.BitLen = strlen(msg.Filter.HexData) * 4;

	//strcpy(msg.StrHexPassword, "12345678");  //��������

	SendSynMsg(gclient, EMESS_BaseWriteEpc, &msg);
	if (msg.rst.RtCode != 0)
	{
		printf("faield to MsgBaseWriteEpc : %s \n", msg.rst.RtMsg);
	}
	else {
		printf("Success to MsgBaseWriteEpc. \n");
	}

	return 0;

}
