#include <stdio.h>
#include <stdlib.h>
#include "delegate.h"
#include "message.h"
#include "GClient.h"

#pragma comment(lib, "GReader")

GClient* gclient;

void __stdcall TagEpcLog(char* readerName, LogBaseEpcInfo msg)
{
	// Any blocking inside the callback will affect the normal use of the API !
	// �ص�������κ���������Ч�ʹ��ͣ�����Ӱ��API������ʹ�� !
	if (msg.Result == 0) {
		printf("EPC: %s\n", msg.Epc);
		printf("TID: %s\n", msg.Tid);
	}
}

void __stdcall TagEpcOver(char* readerName, LogBaseEpcOver msg)
{
	printf("Epc log over. \n");
}

void __stdcall TcpDisconnected(char* readerName)
{
	printf("TCP Disconnected! \n");
	Close(gclient);
}

int main()
{
	gclient = OpenRS232("COM12:115200", 5);
	//gclient = OpenTcpClient("192.168.1.168:8160", 5);

	if (gclient == NULL)
	{
		printf("failed to open connection. \n");
		return 0;
	}

	//Debug log
	gclient->isPrint = TRUE;

	RegCallBack(gclient, ETagEpcLog, (void*)TagEpcLog);
	RegCallBack(gclient, ETagEpcOver, (void*)TagEpcOver);
	//RegCallBack(gclient, ETcpDisconnected, (void*)TcpDisconnected);

	//STOP COMMAND
	MsgBaseStop stop;
	memset(&stop, 0, sizeof(stop));
	SendSynMsg(gclient, EMESS_BaseStop, &stop);
	if (stop.rst.RtCode != 0) {
		printf("Failed to MsgBaseStop: %s. \n", stop.rst.RtMsg);
	}
	else
	{
		printf("Successed to MsgBaseStop. \n");
	}

	//Inventory EPC COMMAND
	MsgBaseInventoryEpc msg;
	memset(&msg, 0, sizeof(msg));
	msg.AntennaEnable = AntennaNo_1;
	msg.InventoryMode = 1;

	//msg.Filter.Area = 2; // TID
	//msg.Filter.Start = 0;
	//memcpy(msg.Filter.HexData, "E2801130200020190FFD019B", 25);
	//msg.Filter.BitLen = strlen(msg.Filter.HexData) * 4;

	msg.ReadTid.Mode = 0;
	msg.ReadTid.Len = 6;

	//msg.ReadUserdata.Start = 0;
	//msg.ReadUserdata.len = 4;

	SendSynMsg(gclient, EMESS_BaseInventoryEpc, &msg);
	if (msg.rst.RtCode != 0)
	{
		printf("Failed to MsgBaseInventoryEpc: %s. \n", msg.rst.RtMsg);
	}
	else {
		printf("Successed to MsgBaseInventoryEpc. \n");
	}

	Sleep(5000);

	//STOP COMMAND
	SendSynMsg(gclient, EMESS_BaseStop, &stop);
	if (stop.rst.RtCode != 0) {
		printf("Failed to MsgBaseStop: %s. \n", stop.rst.RtMsg);
	}
	else
	{
		printf("Successed to MsgBaseStop. \n");
	}

	Sleep(500);

	//CLOSE
	if (gclient->isOpened)
	{
		Close(gclient);
	}

	return 0;
}
