#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <tchar.h> 
#include "delegate.h"
#include "message.h"
#include "GClient.h"

#pragma comment(lib, "GReader")

GClient* gclient;


int main()
{
	gclient = OpenRS232("COM12:115200", 3);

	if (gclient == NULL) {
		printf("failed to connection.\n");
		return 0;
	}
	else {
		printf("succeed to connection.\n");
	}

	MsgBaseSetPower msg;
	memset(&msg, 0, sizeof(msg));
	msg.DicPower[0].AntennaNo = 1;
	msg.DicPower[0].Power = 20;
	msg.DicCount = 1;

	SendSynMsg(gclient, EMESS_BaseSetPower, &msg);
	if (msg.rst.RtCode != 0) {
		printf("failed to MsgBaseSetPower : %s \n", msg.rst.RtMsg);
	}

	printf("Success to MsgBaseSetPower. \n");

	return 0;

}
