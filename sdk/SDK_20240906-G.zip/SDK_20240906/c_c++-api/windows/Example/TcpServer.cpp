#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <tchar.h> 
#include "delegate.h"
#include "message.h"
#include "GClient.h"
#include "GServer.h"

//Tag epc info callback
void __stdcall TagEpcLog(char* readerName, LogBaseEpcInfo msg)
{
	if (msg.Result == 0) {
		printf("SerialNumber: %s\n", msg.readerSerialNumber);
		printf("EPC: %s\n", msg.Epc);
		printf("TID: %s\n", msg.Tid);
		printf("AntId: %d\n", msg.AntId);
		printf("RSSI: %d\n", msg.Rssi);
		printf("ReaderName: %s\n", readerName);
	}
}

//Tag EpcOver callback
void __stdcall TagEpcOver(char* readerName, LogBaseEpcOver msg)
{
	printf("%s - [TagEpcOver].\n", readerName);

}

//TCP Disconnected callback
void TcpDisconnected(char* readerName)
{

	printf("%s Disconnected��\n", readerName);
	//Close(gclient);//Release the current connection

}

void subscribe(GClient* client) {
	RegCallBack(client, ETagEpcLog, (void*)TagEpcLog);
	RegCallBack(client, ETagEpcOver, (void*)TagEpcOver);
	RegCallBack(client, ETcpDisconnected, (void*)TcpDisconnected);
}

void GClientConnected(char* readerName, GClient* client)
{
	GClient* gclient = client;
	subscribe(gclient);
	gclient->isPrint = TRUE;//debug log
	printf("ReaderName = %s, SerialNumber = %s - [Connected].\n", gclient->name, gclient->serialNumber);

	//This is just to test for communication, don't  do it in coding. 
	//You can save client in a list or a map, then take it out and use it elsewhere.
	MsgBaseStop stop;
	memset(&stop, 0, sizeof(stop));
	SendSynMsg(gclient, EMESS_BaseStop, &stop);
	if (stop.rst.RtCode != 0) {
		printf("Failed to MsgBaseStop: %s \n", stop.rst.RtMsg);
	}
	else
	{
		printf("Succeed to MsgBaseStop. \n");
	}

}


int main()
{

	GServer* gserver = (GServer*)malloc(sizeof(GServer));
	if (gserver != nullptr) {
		memset(gserver, 0, sizeof(GServer));
		RegGServerCallBack(gserver, GClientConnected);

		if (OpenTcpServer(8160, gserver)) {
			printf("Start listening ...\n");

		}
	}
	printf("Press any key to end this program\n");

	//Prevents the program from ending automatically
	getchar();
	
	return 0;
}
