#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <tchar.h> 
#include "delegate.h"
#include "message.h"
#include "GClient.h"

#pragma comment(lib, "GReader")

GClient* gclient;

void __stdcall TagEpcLog(char* readerName, LogBaseEpcInfo msg)
{
	if (msg.Result == 0) {
		printf("EPC: %s\n", msg.Epc);
		printf("TID: %s\n", msg.Tid);
		printf("AntId: %d\n", msg.AntId);
		printf("readerName: %s\n", readerName);

	}
}

void __stdcall TagEpcOver(char* readerName, LogBaseEpcOver msg)
{
	printf("readerName: %s - [TagEpcOver].\n", readerName);

}


int main()
{
	gclient = OpenRS232("COM12:115200", 3);

	if (gclient == NULL) {
		printf("failed to connection.\n");
		return 0;
	}
	else {
		printf("succeed to connection.\n");
	}

	//debug log
	//gclient->isPrint = TRUE;

	RegCallBack(gclient, ETagEpcLog, (void*)TagEpcLog);
	RegCallBack(gclient, ETagEpcOver, (void*)TagEpcOver);

	MsgBaseStop stop;
	memset(&stop, 0, sizeof(stop));
	SendSynMsg(gclient, EMESS_BaseStop, &stop);
	if (stop.rst.RtCode != 0) {
		printf("failed to MsgBaseStop: %s \n", stop.rst.RtMsg);
		return 0;
	}
	else
	{
		printf("Success to MsgBaseStop. \n");
	}

	Sleep(500);

	MsgBaseInventoryEpc msg;
	memset(&msg, 0, sizeof(msg));
	//single antenna
	msg.AntennaEnable = AntennaNo_1;
	//multi antenna
	//msg.AntennaEnable = AntennaNo_1 | AntennaNo_2 | AntennaNo_3 | AntennaNo_4;

	msg.InventoryMode = eInventory;

	msg.ReadTid.Mode = 0;
	msg.ReadTid.Len = 6;

	//ƥ�����
	msg.Filter.Area = 2;//TID
	msg.Filter.BitStart = 0;
	memcpy(msg.Filter.HexData, "E28068902000400E86B21C9E", 24);
	msg.Filter.BitLen = strlen(msg.Filter.HexData) * 4;

	SendSynMsg(gclient, EMESS_BaseInventoryEpc, &msg);

	if (msg.rst.RtCode != 0)
	{
		printf("failed to MsgBaseInventoryEpc: %s \n", msg.rst.RtMsg);
	}
	else {
		printf("Success to MsgBaseInventoryEpc. \n");
	}

	Sleep(5000);

	memset(&stop, 0, sizeof(stop));
	SendSynMsg(gclient, EMESS_BaseStop, &stop);
	if (stop.rst.RtCode != 0) {
		printf("failed to MsgBaseStop: %s \n", stop.rst.RtMsg);
		return 0;
	}
	else
	{
		printf("Success to MsgBaseStop. \n");
	}

	Sleep(500);

	printf("Close connection.\n");
	Close(gclient);

	return 0;

}
