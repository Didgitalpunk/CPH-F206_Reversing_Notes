#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <tchar.h> 
#include "delegate.h"
#include "message.h"
#include "GClient.h"

#pragma comment(lib, "GReader")

GClient* gclient;


int main()
{
	gclient = OpenRS232("COM12:115200", 3);

	if (gclient == NULL) {
		printf("failed to connection.\n");
		return 0;
	}
	else {
		printf("succeed to connection.\n");
	}

	MsgBaseWriteEpc msg;
	memset(&msg, 0, sizeof(msg));

	msg.AntennaEnable = AntennaNo_1;
	msg.Area = 3;	// 0����������1��EPC ����2��TID ����3���û�������
	msg.Start = 0;
	memset(msg.StrHexWriteData, 0, 25);
	strcpy(msg.StrHexWriteData, "2222");

	msg.Filter.Area = 2;
	msg.Filter.BitStart = 0;
	
	memset(msg.Filter.HexData, 0, 25);
	strcpy(msg.Filter.HexData, "E2003412012F030000D9944D");
	msg.Filter.BitLen = strlen(msg.Filter.HexData) * 4;

	//strcpy(msg.StrHexPassword, "12345678");

	SendSynMsg(gclient, EMESS_BaseWriteEpc, &msg);
	if (msg.rst.RtCode != 0)
	{
		printf("faield to MsgBaseWriteEpc : %s \n", msg.rst.RtMsg);
	}
	else {
		printf("Success to MsgBaseWriteEpc. \n");
	}

	return 0;

}
