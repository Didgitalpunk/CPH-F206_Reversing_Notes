#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <tchar.h> 
#include "delegate.h"
#include "message.h"
#include "GClient.h"

#pragma comment(lib, "GReader")

GClient* gclient;

void Tag6bOver(char* readerName, LogBase6bOver msg)
{
	printf("Tag6BOver \n");
}

int main()
{
	gclient = OpenRS232("COM12:115200", 3);

	if (gclient == NULL) {
		printf("Failed to connection.\n");
		return 0;
	}
	else {
		printf("Succeed to connection.\n");
	}

	MsgBaseWrite6B msg;
	memset(&msg, 0, sizeof(msg));

	msg.AntennaEnable = AntennaNo_1;

	int tidLen = 8;
	msg.TidLength = tidLen;
	memset(msg.StrHexMatchTid, 0, 17);
	strcpy(msg.StrHexMatchTid, "E0040000FA837406");

	msg.Start = 14;

	int dataLen = 2;
	msg.DataLength = dataLen;
	memset(msg.StrHexWriteData, 0, 5);
	strcpy(msg.StrHexWriteData, "1234");

	SendSynMsg(gclient, EMESS_BaseWrite6b, &msg);
	if (msg.rst.RtCode != 0)
	{
		printf("Failed to MsgBaseWrite6B: %s.\n", msg.rst.RtMsg);
	}
	else
	{
		printf("Succeed to MsgBaseWrite6B.\n");
	}
	
	return 0;

}
