#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <tchar.h> 
#include "delegate.h"
#include "message.h"
#include "GClient.h"

#pragma comment(lib, "GReader")

GClient* gclient;


int main()
{
	gclient = OpenRS232("COM12:115200", 3);

	if (gclient == NULL) {
		printf("failed to connection.\n");
		return 0;
	}
	else {
		printf("succeed to connection.\n");
	}

	MsgBaseLockGet6B msg;
	memset(&msg, 0, sizeof(msg));

	msg.AntennaEnable = AntennaNo_1;

	int tidLen = 8;
	msg.TidLength = tidLen;
	memset(msg.StrHexMatchTid, 0, 17);
	strcpy(msg.StrHexMatchTid, "E045EE0001A00F0D");

	msg.Address = 8;

	SendSynMsg(gclient, EMESS_BaseLockGet6b, &msg);
	if (msg.rst.RtCode != 0)
	{
		printf("Failed to MsgBaseLockGet6B: %s.\n", msg.rst.RtMsg);
	}
	else
	{
		printf("Success to MsgBaseLockGet6B.\n");
		if (msg.setLockStateFlag > 0) {
			printf("LockState : %d\n", msg.LockState);
		}
	}

	return 0;

}
