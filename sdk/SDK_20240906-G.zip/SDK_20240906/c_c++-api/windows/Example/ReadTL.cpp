#include <stdio.h>
#include <string.h>
#include "delegate.h"
#include "message.h"
#include "GClient.h"
#include "GServer.h"
#include <stdlib.h>
#include <tchar.h> 


#pragma comment(lib, "GReader")

GClient* client;


void __stdcall TagTLLog(char* readerName, LogBaseTLInfo msg)
{
	printf("EPC: %s\n", msg.Epc);
	printf("TID: %s\n", msg.Tid);
	printf("RSSI: %d\n", msg.Rssi);
}

void __stdcall TagTLOver(char* readerName, LogBaseTLOver msg)
{
	printf("%s - TagTLOver \n", readerName);
}

int main()
{
	client = OpenRS232("COM3:115200", 3);

	if (client != NULL) {
		client->isPrint = TRUE;
		RegCallBack(client, ETagTLLog, (void*)TagTLLog);
		RegCallBack(client, ETagTLOver, (void*)TagTLOver);
		printf("success open client \n");

		MsgBaseStop stop;
		memset(&stop, 0, sizeof(stop));
		SendSynMsg(client, EMESS_BaseStop, &stop);
		if (stop.rst.RtCode != 0) {
			printf("failed to MsgBaseStop: %s \n", stop.rst.RtMsg);
		}
		else
		{
			printf("Success to MsgBaseStop. \n");
		}

		//inventory GB/T25340 tags
		MsgBaseInventoryTL inventoryTL;
		memset(&inventoryTL, 0, sizeof(inventoryTL));
		inventoryTL.AntennaEnable = AntennaNo_1;
		inventoryTL.InventoryMode = InventoryMode_Inventory;
		SendSynMsg(client, EMESS_BaseInventoryTL, &inventoryTL);
		if (inventoryTL.rst.RtCode != 0) {
			printf("Failed to MsgBaseInventoryTL: %s \n", inventoryTL.rst.RtMsg);
		}
		else {
			printf("Success to MsgBaseInventoryTL. \n");
		}

		Sleep(5000);

		//inventory 5 second, then stop inventory.
		memset(&stop, 0, sizeof(stop));
		SendSynMsg(client, EMESS_BaseStop, &stop);
		if (stop.rst.RtCode != 0) {
			printf("failed to MsgBaseStop: %s \n", stop.rst.RtMsg);
		}
		else
		{
			printf("Success to MsgBaseStop. \n");
		}
	}
}
