#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <tchar.h> 
#include "delegate.h"
#include "message.h"
#include "GClient.h"

#pragma comment(lib, "GReader")

GClient* gclient;


int main()
{
	gclient = OpenRS232("COM12:115200", 3);

	if (gclient == NULL) {
		printf("failed to connection.\n");
		return 0;
	}
	else {
		printf("succeed to connection.\n");
	}

	MsgBaseLock6B msg;
	memset(&msg, 0, sizeof(msg));

	msg.AntennaEnable = AntennaNo_1;

	int tidLen = 8;
	msg.TidLength = tidLen;
	memset(msg.StrHexMatchTid, 0, 17);
	strcpy(msg.StrHexMatchTid, "E0040000FA837406");

	msg.Address = 8;

	SendSynMsg(gclient, EMESS_BaseLock6b, &msg);
	if (msg.rst.RtCode != 0)
	{
		printf("Failed to MsgBaseLock6B: %s .\n", msg.rst.RtMsg);
		if (msg.setErrorAddressFlag > 0) {
			printf("Error Adress : %d\n", msg.ErrorAddress);
		}
	}
	else
	{
		printf("Success to MsgBaseLock6B.\n");
	}

	return 0;

}
