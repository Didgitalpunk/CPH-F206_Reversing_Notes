#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <tchar.h> 
#include "delegate.h"
#include "message.h"
#include "GClient.h"

#pragma comment(lib, "GReader")

GClient* gclient;
int count = 0;

void Tag6bLog(char* readerName, LogBase6bInfo msg)
{
	if (msg.Result == 0) {
		printf("TID: %s\n", msg.Tid);
		printf("USER: %s\n", msg.Userdata);
		printf("RSSI: %d\n", msg.Rssi);
		count++;
	}
}

void Tag6bOver(char* readerName, LogBase6bOver msg)
{
	printf("Tag6BOver \n");
	printf("count = %d \n", count);
}

int main()
{
	gclient = OpenRS232("COM12:115200", 3);

	if (gclient == NULL) {
		printf("Failed to connection.\n");
		return 0;
	}
	else {
		printf("Succeed to connection.\n");
	}

	RegCallBack(gclient, ETag6bLog, (void*)Tag6bLog);
	RegCallBack(gclient, ETag6bOver, (void*)Tag6bOver);

	MsgBaseInventory6B msg;
	memset(&msg, 0, sizeof(msg));

	msg.AntennaEnable = AntennaNo_1;
	msg.InventoryMode = 1;

	msg.Area = 1;

	msg.setReadUserdataFlag = 1;
	msg.ReadUserdata.Start = 0;
	msg.ReadUserdata.Len = 8;

	/*msg.setMatchTidFlag = 1;
	int len = 16;
	msg.TidLenth = len / 2;
	memset(msg.StrHexMatchTid, 0, len);
	strcpy(msg.StrHexMatchTid, "E0040000FA837406");*/

	SendSynMsg(gclient, EMESS_BaseInventory6b, &msg);
	if (msg.rst.RtCode != 0)
	{
		printf("failed to MsgBaseInventory6B: %s .\n", msg.rst.RtMsg);
	}
	else
	{
		printf("Succeed to MsgBaseInventory6B.\n");
	}

	Sleep(5000);

	MsgBaseStop stop;
	memset(&stop, 0, sizeof(stop));
	SendSynMsg(gclient, EMESS_BaseStop, &stop);
	if (stop.rst.RtCode != 0) {
		printf("failed to MsgBaseStop: %s \n", stop.rst.RtMsg);
		return 0;
	}
	else
	{
		printf("Succeed to MsgBaseStop. \n");
	}

	Sleep(500);

	return 0;

}
