#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <tchar.h> 
#include "delegate.h"
#include "message.h"
#include "GClient.h"

GClient* gclient;

//����TCP�Ͽ������ϱ�
void TcpDisconnected(char* readerName)
{

	printf("%s Disconnected��\n", readerName);
	Close(gclient);//�ͷŵ�ǰ������Դ

}

int main()
{
	gclient = OpenTcpClient("192.168.1.168:8160", 3);

	if (gclient == NULL) {
		printf("failed to connection.\n");
		return 0;
	}
	else {
		printf("succeed to connection.\n");
	}

	RegCallBack(gclient, ETcpDisconnected, (void*)TcpDisconnected);

	MsgBaseStop stop;
	memset(&stop, 0, sizeof(stop));
	SendSynMsg(gclient, EMESS_BaseStop, &stop);
	if (stop.rst.RtCode != 0) {
		printf("failed to MsgBaseStop: %s \n", stop.rst.RtMsg);
		return 0;
	}
	else
	{
		printf("succeed to MsgBaseStop. \n");
	}

	return 0;
}
