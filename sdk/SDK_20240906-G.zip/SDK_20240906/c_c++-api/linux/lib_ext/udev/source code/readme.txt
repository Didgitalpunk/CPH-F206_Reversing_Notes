1.Unzip the file
tar -xvf eudev-3.2.11.tar.gz

2.Generate the Makefile file, such as: 
./configure --host=arm-linux-gnueabihf --prefix=/usr/local/arm/gcc-7.5.0 CC=/usr/local/arm/gcc-7.5.0/bin/arm-linux-gnueabihf-gcc --enable-udev=false

3.make

4.make install