#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include "delegate.h"
#include "message.h"
#include "GClient.h"

GClient *client;

void TagEpcLog(char *readerName, LogBaseEpcInfo msg) {
    if (msg.Result == 0) {
        printf("EPC: %s\n", msg.Epc);
        printf("TID: %s\n", msg.Tid);
    }
}

void TagEpcOver(char *readerName, LogBaseEpcOver msg) {
    printf("TagEpcOver \n");
}

void TcpDisconnected(char* readerName) {
    printf("%s - Disconnected \n", readerName);
    Close(client);
}

int main() {

    printf("please select the way of connection: 1.rs232 2.rs485 3.tcp \n");
    int way = 0;

    if (scanf("%d", &way) != EOF) {

        switch (way) {
            case 1: {
                client = OpenRS232("/dev/ttyUSB0:115200", 5);
            }
                break;
            case 2: {
                client = OpenRS485("/dev/ttyUSB0:115200:1", 5);
            }
                break;

            case 3: {
                client = OpenTcpClient("192.168.1.168:8160", 5);
            }
                break;

        }
    }

    if (client == nullptr) {
        printf("failed to connection \n");
        return 0;
    } else {
        printf("success to connection \n");
    }

    //Debug log
    client->isPrint = true;

    RegCallBack(client, ETagEpcLog, (void *) TagEpcLog);
    RegCallBack(client, ETagEpcOver, (void *) TagEpcOver);
    RegCallBack(client, ETcpDisconnected, (void*)TcpDisconnected);

    //STOP COMMAND
    MsgBaseStop stop;
    memset(&stop, 0, sizeof(stop));
    SendSynMsg(client, EMESS_BaseStop, &stop);
    if (stop.rst.RtCode != 0) {
        printf("Failed to MsgBaseStop: %s. \n", stop.rst.RtMsg);
    } else {
        printf("Success to MsgBaseStop. \n");
    }

    //Inventory EPC COMMAND
    MsgBaseInventoryEpc msg;
    memset(&msg, 0, sizeof(msg));
    //single antenna
    msg.AntennaEnable =  AntennaNo_1;
    //multi antenna
//    msg.AntennaEnable =  AntennaNo_1 | AntennaNo_2;
    msg.InventoryMode = InventoryMode_Inventory;

    //msg.Filter.Area = 2; // TID
    //msg.Filter.Start = 0;
    //memcpy(msg.Filter.HexData, "E2801130200020190FFD019B", 25);
    //msg.Filter.BitLen = strlen(msg.Filter.HexData) * 4;

    msg.ReadTid.Mode = 0;
    msg.ReadTid.Len = 6;

    //msg.ReadUserdata.Start = 0;
    //msg.ReadUserdata.len = 4;

    SendSynMsg(client, EMESS_BaseInventoryEpc, &msg);
    if (msg.rst.RtCode != 0) {
        printf("Failed to MsgBaseInventoryEpc: %s. \n", msg.rst.RtMsg);
    } else {
        printf("Success to MsgBaseInventoryEpc. \n");
    }

    sleep(5);

    //STOP COMMAND
    SendSynMsg(client, EMESS_BaseStop, &stop);
    if (stop.rst.RtCode != 0) {
        printf("Failed to MsgBaseStop: %s. \n", stop.rst.RtMsg);
    } else {
        printf("Success to MsgBaseStop. \n");
    }

    usleep(500);

    //CLOSE
    if (client->isOpened) {
        Close(client);
    }

    return 0;
}
