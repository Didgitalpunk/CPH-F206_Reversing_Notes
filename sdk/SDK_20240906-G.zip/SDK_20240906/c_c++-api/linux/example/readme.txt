参考windows下example示例

See example in windows