﻿using GDotnet.Reader.Api.DAL;
using GDotnet.Reader.Api.Protocol.Gx;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;


// ==============================================================
//   Copyright (C) 2019 SZGxwl Inc. All rights reserved.
// 
//   Create by xiao.liu at 2019/1/11 11:22:51.
//
//   xiao.liu [mailto:fanqie0127@gmail.com]
// ============================================================== 
namespace GDotnet.Reader.Api
{
    static class Example
    {
        static void Main()
        {
            GClient clientConn = new GClient();
            eConnectionAttemptEventStatusType status;
            // clientConn.OpenSerial("COM18:115200", 3000, out status)
            if (clientConn.OpenTcp("192.168.1.168:8160", 3000, out status))
            {
                // subscribe to event
                clientConn.OnEncapedTagTlLog += new delegateEncapedTagTlLog(OnEncapedTagTlLog);
                clientConn.OnEncapedTagTlOver += new delegateEncapedTagTlOver(OnEncapedTagTlOver);

                // stop 
                MsgBaseStop msgBaseStop = new MsgBaseStop();
                clientConn.SendSynMsg(msgBaseStop);
                if (0 == msgBaseStop.RtCode)
                {
                    Console.WriteLine("Stop successful.");
                }
                else { Console.WriteLine("Stop error."); }

                MsgBaseInventoryTl msgBaseInventoryTl = new MsgBaseInventoryTl();
                msgBaseInventoryTl.AntennaEnable = (uint)(eAntennaNo._1);
                // msgBaseInventoryEpc.AntennaEnable = (uint)(eAntennaNo._1 | eAntennaNo._2);           // 多天线
                msgBaseInventoryTl.InventoryMode = (byte)eInventoryMode.Inventory;
                clientConn.SendSynMsg(msgBaseInventoryTl);
                if (0 == msgBaseInventoryTl.RtCode)
                {
                    Console.WriteLine("Inventory epc successful.");
                }
                else { Console.WriteLine("Inventory epc error."); }
                Console.WriteLine("Reading....");
                Console.WriteLine("按任意键停止循环读卡(Enter any character to stop).");
                Console.ReadKey();

                // stop
                clientConn.SendSynMsg(msgBaseStop);
                if (0 == msgBaseStop.RtCode)
                {
                    Console.WriteLine("Stop successful.");
                }
                else { Console.WriteLine("Stop error."); }
            }
            else 
            {
                Console.WriteLine("Connect failure.");
            }
            Console.ReadKey();
        }

        #region API事件
        
        public static void OnEncapedTagTlLog(EncapedLogBaseTlInfo msg)
        {
            // Any blocking inside the callback will affect the normal use of the API !
            // 回调里面的任何阻塞或者效率过低，都会影响API的正常使用 !
            if (null != msg && 0 == msg.logBaseTlInfo.Result) 
            {
                Console.WriteLine(msg.reader + ":ant[" + msg.logBaseTlInfo.AntId + "]" + msg.logBaseTlInfo.Epc + "|" + msg.logBaseTlInfo.ViewData);
            }
        }

        public static void OnEncapedTagTlOver(EncapedLogBaseTlOver msg)
        {
            if (null != msg)
            {
                Console.WriteLine("TL log over.");
            }
        }

        #endregion
    }
}
