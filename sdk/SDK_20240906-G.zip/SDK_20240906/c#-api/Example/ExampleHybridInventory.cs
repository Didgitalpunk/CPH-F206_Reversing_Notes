﻿using GDotnet.Reader.Api.DAL;
using GDotnet.Reader.Api.Protocol.Gx;
using System;
using System.Collections.Generic;
using System.Text;


// ==============================================================
//   Copyright (C) 2023 SZGxwl Inc. All rights reserved.
// 
//   Create by xiao.liu at 2023-03-13 16:06:13.
//
//   xiao.liu [mailto:fanqie0127@gmail.com]
// ============================================================== 
namespace GDotnet.Reader.Api.Example
{
    static class ExampleHybridInventory
    {
        static void Main()
        {
            GClient clientConn = new GClient();
            eConnectionAttemptEventStatusType status;
            // clientConn.OpenTcp("192.168.1.168:8160", 3000, out status)
            if (clientConn.OpenSerial("COM11:115200", 3000, out status))
            {
                // subscribe to event
                clientConn.OnEncapedTagEpcLog += new delegateEncapedTagEpcLog(OnEncapedTagEpcLog);
                clientConn.OnEncapedTagEpcOver += new delegateEncapedTagEpcOver(OnEncapedTagEpcOver);
                clientConn.OnEncapedTag6bLog += new delegateEncapedTag6bLog(OnEncapedTag6bLog);
                clientConn.OnEncapedTag6bOver += new delegateEncapedTag6bOver(OnEncapedTag6bOver);

                // stop 
                MsgBaseStop msgBaseStop = new MsgBaseStop();
                clientConn.SendSynMsg(msgBaseStop);
                if (0 == msgBaseStop.RtCode)
                {
                    Console.WriteLine("Stop successful.");
                }
                else { Console.WriteLine("Stop error."); }

                // 4 antenna read Inventory, 6c & 6b
                MsgBaseInventoryHybrid inventoryHybrid = new MsgBaseInventoryHybrid();
                inventoryHybrid.AntennaEnable = (uint)(eAntennaNo._1 | eAntennaNo._2 | eAntennaNo._3 | eAntennaNo._4);
                inventoryHybrid.InventoryMode = (byte)eInventoryMode.Inventory;
                inventoryHybrid.HybridEpc = new ParamHybridEpc();
                inventoryHybrid.HybridEpc.ReadTid = new ParamEpcReadTid();
                inventoryHybrid.HybridEpc.ReadTid.Mode = (byte)eParamTidMode.Auto;
                inventoryHybrid.HybridEpc.ReadTid.Len = 6;

                inventoryHybrid.Hybrid6b = new ParamHybrid6b();
                inventoryHybrid.Hybrid6b.Area = (byte)e6bReadMode.TidAndUserdata;                // tid & user data 

                inventoryHybrid.Hybrid6b.ReadUserdata = new Param6bReadUserdata();
                inventoryHybrid.Hybrid6b.ReadUserdata.Start = 12;
                inventoryHybrid.Hybrid6b.ReadUserdata.Len = 6;
                clientConn.SendSynMsg(inventoryHybrid);
                if (0 == inventoryHybrid.RtCode)
                {
                    Console.WriteLine("Inventory Hybrid successful.");
                }
                else { Console.WriteLine("Inventory Hybrid error."); }
                Console.WriteLine("Reading....");
                Console.WriteLine("按任意键停止循环读卡(Enter any character to stop).");
                Console.ReadKey();
                
                // stop
                clientConn.SendSynMsg(msgBaseStop);
                if (0 == msgBaseStop.RtCode)
                {
                    Console.WriteLine("Stop successful.");
                }
                else { Console.WriteLine("Stop error."); }
                // close connect.
                clientConn.OnEncapedTagEpcLog -= new delegateEncapedTagEpcLog(OnEncapedTagEpcLog);
                clientConn.OnEncapedTagEpcOver -= new delegateEncapedTagEpcOver(OnEncapedTagEpcOver);
                clientConn.OnEncapedTag6bLog -= new delegateEncapedTag6bLog(OnEncapedTag6bLog);
                clientConn.OnEncapedTag6bOver -= new delegateEncapedTag6bOver(OnEncapedTag6bOver);
                clientConn.Close();
            }
            else
            {
                Console.WriteLine("Connect failure.");
            }
            Console.ReadKey();
        }

        #region API事件

        public static void OnEncapedTagEpcLog(EncapedLogBaseEpcInfo msg)
        {
            // Any blocking inside the callback will affect the normal use of the API !
            // 回调里面的任何阻塞或者效率过低，都会影响API的正常使用 !
            if (null != msg && 0 == msg.logBaseEpcInfo.Result)
            {
                Console.WriteLine(msg.reader + "[6c]:ant[" + msg.logBaseEpcInfo.AntId + "]" + msg.logBaseEpcInfo.Epc + "|" + msg.logBaseEpcInfo.Tid);
            }
        }

        public static void OnEncapedTagEpcOver(EncapedLogBaseEpcOver msg)
        {
            if (null != msg)
            {
                Console.WriteLine("Epc log over.");
            }
        }

        public static void OnEncapedTag6bLog(EncapedLogBase6bInfo msg)
        {
            // Any blocking inside the callback will affect the normal use of the API !
            // 回调里面的任何阻塞或者效率过低，都会影响API的正常使用 !
            if (null != msg && 0 == msg.logBase6bInfo.Result)
            {
                Console.WriteLine(msg.reader + "[6b]:ant[" + msg.logBase6bInfo.AntId + "]" + msg.logBase6bInfo.Tid + "|" + msg.logBase6bInfo.Userdata);
            }
        }

        public static void OnEncapedTag6bOver(EncapedLogBase6bOver msg)
        {
            if (null != msg)
            {
                Console.WriteLine("6b log over.");
            }
        }

        #endregion
    }
}
