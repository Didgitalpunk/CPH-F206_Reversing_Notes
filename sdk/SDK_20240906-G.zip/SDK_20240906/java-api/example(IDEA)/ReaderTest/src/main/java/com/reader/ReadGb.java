package com.reader;

import com.gg.reader.api.dal.*;
import com.gg.reader.api.protocol.gx.*;

import java.util.Scanner;

public class ReadGb {
    public static void main(String[] args) {
        GClient client = new GClient();
        //        if (client.openTcp("192.168.1.168:8160", 0))
        if (client.openJSerial("COM7:115200")) {

            subscribeHandler(client);

            MsgBaseInventoryGb msgBaseInventoryGb = new MsgBaseInventoryGb();
            msgBaseInventoryGb.setAntennaEnable(EnumG.AntennaNo_1);//1号天线， 1、2号天线 = EnumG.AntennaNo_1|EnumG.AntennaNo_2
            msgBaseInventoryGb.setInventoryMode(EnumG.InventoryMode_Inventory);
            client.sendSynMsg(msgBaseInventoryGb);
            if (0x00 == msgBaseInventoryGb.getRtCode()) {
                System.out.println("MsgBaseInventoryGb[OK].");
            } else {
                System.out.println(msgBaseInventoryGb.getRtMsg());
            }

            try {
                Thread.sleep(5000);
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }

            MsgBaseStop stopMsg = new MsgBaseStop();
            client.sendSynMsg(stopMsg);
            if (0x00 == stopMsg.getRtCode()) {
                System.out.println("MsgBaseStop Success");
            } else {
                System.out.println("MsgBaseStop Fail");
            }

            System.out.println("Close the connection");
            client.close();
        }
    }

    //订阅GB标签信息上报
    private static void subscribeHandler(GClient client) {
        client.onTagGbLog = new HandlerTagGbLog() {
            @Override
            public void log(String s, LogBaseGbInfo logBaseGbInfo) {
                if (null != logBaseGbInfo && logBaseGbInfo.getResult() == 0) {
                    System.out.println(logBaseGbInfo);
                }
            }
        };

        client.onTagGbOver = new HandlerTagGbOver() {
            @Override
            public void log(String s, LogBaseGbOver logBaseGbOver) {
                System.out.println("HandlerTagGbOver");
            }
        };

    }
}
