package com.reader;

import com.gg.reader.api.dal.GClient;
import com.gg.reader.api.protocol.gx.EnumG;
import com.gg.reader.api.protocol.gx.MsgBaseLockGb;
import com.gg.reader.api.protocol.gx.ParamEpcFilter;

import java.util.Scanner;

public class LockGb {
    public static void main(String[] args) {
        GClient client = new GClient();
        //        if (client.openTcp("192.168.1.168:8160", 0))
        if (client.openJSerial("COM7:115200")) {
            MsgBaseLockGb msg = new MsgBaseLockGb();
            msg.setAntennaEnable(EnumG.AntennaNo_1);
            msg.setArea(0x10);//锁编码区
            msg.setLockParam(0x01);//0x00，可读可写。0x01，可读不可写。0x02，不可读可写。0x03，不可读不可写。

            //匹配标签锁
//            String tid = "E280110520007B05A8C208A8";
//            ParamEpcFilter filter = new ParamEpcFilter();
//            filter.setArea(0x00);
//            filter.setHexData(tid);
//            filter.setBitStart(0);
//            filter.setBitLength(tid.length() * 4);
//            msg.setFilter(filter);

            msg.setHexPassword("12345678");//写入安全区的密码
            client.sendSynMsg(msg);
            if (0x00 == msg.getRtCode()) {
                System.out.println("Lock successful.");
            } else {
                System.out.println(msg.getRtMsg());
            }
        }
    }
}
