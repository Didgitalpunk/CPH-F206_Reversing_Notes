package com.reader;

import com.gg.reader.api.dal.GClient;
import com.gg.reader.api.dal.HandlerTagTLLog;
import com.gg.reader.api.dal.HandlerTagTLOver;
import com.gg.reader.api.protocol.gx.EnumG;
import com.gg.reader.api.protocol.gx.LogBaseTLInfo;
import com.gg.reader.api.protocol.gx.LogBaseTLOver;
import com.gg.reader.api.protocol.gx.MsgBaseInventoryTL;

import java.util.Scanner;

public class ReadTL {
    public static void main(String[] args) {
        GClient client = new GClient();
        //        if (client.openTcp("192.168.1.168:8160", 0))
       if (client.openJSerial("COM7:115200")) {

            subscribeHandler(client);
            MsgBaseInventoryTL msg = new MsgBaseInventoryTL();
            msg.setAntennaEnable(EnumG.AntennaNo_1);//1号天线， 1、2号天线 = EnumG.AntennaNo_1|EnumG.AntennaNo_2
            msg.setInventoryMode(EnumG.InventoryMode_Inventory);
            client.sendSynMsg(msg);
            System.err.println(msg.getRtCode() + "-->" + msg.getRtMsg());
        }
    }

    //订阅标签信息上报
    private static void subscribeHandler(GClient client) {
        client.onTagTLog = new HandlerTagTLLog() {
            @Override
            public void log(String s, LogBaseTLInfo logBaseTLInfo) {
                System.err.println(logBaseTLInfo);
            }
        };
        client.onTagTLOver = new HandlerTagTLOver() {
            @Override
            public void log(String s, LogBaseTLOver logBaseTLOver) {

            }
        };
    }
}
