package com.reader;

import com.gg.reader.api.dal.GClient;
import com.gg.reader.api.protocol.gx.MsgAppSetBeep;

import java.util.Scanner;

public class SetBeep {
    public static void main(String[] args) {
        GClient client = new GClient();
        //        if (client.openTcp("192.168.1.168:8160", 0))
          if (client.openJSerial("COM7:115200")) {

            MsgAppSetBeep msg=new MsgAppSetBeep();
            msg.setBeepStatus(1);//0-停止 1-响
            msg.setBeepMode(0);//0-响一次 1-常响
            client.sendSynMsg(msg);
            if (msg.getRtCode()==0){
                System.out.println(msg.getRtMsg());
            }else {
                System.err.println(msg.getRtMsg());
            }

        }
    }
}
