package com.reader;

import com.gg.reader.api.dal.GClient;
import com.gg.reader.api.protocol.gx.EnumG;
import com.gg.reader.api.protocol.gx.MsgBaseWriteGb;

import java.util.Scanner;

public class WriteGbEpc {
    public static void main(String[] args) {
        GClient client = new GClient();
        //        if (client.openTcp("192.168.1.168:8160", 0))
       if (client.openJSerial("COM7:115200")) {

            MsgBaseWriteGb msg = new MsgBaseWriteGb();
            msg.setAntennaEnable(EnumG.AntennaNo_1);
            //0x10:标签编码区 | 0x20:标签安全区 | 0x30~0x3F:用户子区0~15
            msg.setArea(0x10);
            msg.setStart(0);//word
            String data = "AAAA";
            int len = PcUtils.getValueLen(data);
            String s = PcUtils.getGbPc(len) + PcUtils.padLeft(data, len * 4, '0');
            msg.setHexWriteData(s);
            client.sendSynMsg(msg);
            if (0x00 == msg.getRtCode()) {
                System.out.println("Write successful.");
            } else {
                System.out.println(msg.getRtMsg());
            }
        }
    }
}
