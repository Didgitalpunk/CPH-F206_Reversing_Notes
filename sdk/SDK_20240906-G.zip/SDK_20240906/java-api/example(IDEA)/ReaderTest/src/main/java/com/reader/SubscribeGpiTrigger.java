package com.reader;

import com.gg.reader.api.dal.*;
import com.gg.reader.api.protocol.gx.*;

import java.util.Scanner;

public class SubscribeGpiTrigger {
    public static void main(String[] args) {
        GClient client = new GClient();
        //        if (client.openTcp("192.168.1.168:8160", 0))
         if (client.openJSerial("COM7:115200")) {

            subscribeHandler(client);
			//执行触发GPI动作 即可收到上报
        }
    }

    //订阅gpi触发上报
    private static void subscribeHandler(GClient client) {
        client.onGpiStart = new HandlerGpiStart() {
            @Override
            public void log(String s, LogAppGpiStart logAppGpiStart) {
                //索引从0开始
                if (null != logAppGpiStart) {
                    System.out.println(logAppGpiStart);
                }
            }
        };

        client.onGpiOver = new HandlerGpiOver() {
            @Override
            public void log(String s, LogAppGpiOver logAppGpiOver) {
                if (null != logAppGpiOver) {
                    System.out.println(logAppGpiOver);
                }
            }
        };
    }
}
