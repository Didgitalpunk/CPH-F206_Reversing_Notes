package com.reader;

import com.gg.reader.api.dal.*;
import com.gg.reader.api.protocol.gx.*;

import java.util.Scanner;

public class ReadGJb {
    public static void main(String[] args) {
        GClient client = new GClient();
        //        if (client.openTcp("192.168.1.168:8160", 0))
         if (client.openJSerial("COM7:115200")) {

            subscribeHandler(client);

            MsgBaseInventoryGJb msg = new MsgBaseInventoryGJb();
            msg.setAntennaEnable(EnumG.AntennaNo_1);//1号天线， 1、2号天线 = EnumG.AntennaNo_1|EnumG.AntennaNo_2
            msg.setInventoryMode(EnumG.InventoryMode_Inventory);

            //同时读TID
//            msg.setReadTid(new ParamEpcReadTid(0,6));

            //同时读UserData
//            msg.setReadUserdata(new ParamEpcReadUserdata(0,2));

            //匹配TID读 E280110520007B05A8C208A8  可选参数
//            ParamEpcFilter filter = new ParamEpcFilter();
//            String tid = "E280110520007B05A8C208A8";
//            filter.setArea(0x00);
//            filter.setBitStart(0);
//            filter.setHexData(tid);
//            filter.setBitLength(tid.length() * 4);
//            msg.setFilter(filter);

            client.sendSynMsg(msg);
            if (0x00 == msg.getRtCode()) {
                System.out.println("MsgBaseInventoryGJb[OK].");
            } else {
                System.out.println(msg.getRtMsg());
            }

            try {
                Thread.sleep(5000);
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }

            MsgBaseStop stopMsg = new MsgBaseStop();
            client.sendSynMsg(stopMsg);
            if (0x00 == stopMsg.getRtCode()) {
                System.out.println("MsgBaseStop Success");
            } else {
                System.out.println("MsgBaseStop Fail");
            }

            System.out.println("Close the connection");
            client.close();
        }
    }

    //订阅GJB标签信息上报
    private static void subscribeHandler(GClient client) {
        client.onTagGJbLog = new HandlerTagGJbLog() {
            @Override
            public void log(String s, LogBaseGJbInfo logBaseGjbInfo) {
                if (logBaseGjbInfo.getResult() == 0) {
                    System.out.println(logBaseGjbInfo);
                }
            }
        };

        client.onTagGJbOver = new HandlerTagGJbOver() {
            @Override
            public void log(String s, LogBaseGJbOver logBaseGjbOver) {
                System.out.println("HandlerTagGjbOver");
            }
        };

    }
}
