package com.reader;

import com.gg.reader.api.dal.GClient;
import com.gg.reader.api.protocol.gx.EnumG;
import com.gg.reader.api.protocol.gx.MsgBaseWriteEpc;

import java.util.Scanner;

public class WriteEpcReserveData {
    public static void main(String[] args) {
        GClient client = new GClient();
        //        if (client.openTcp("192.168.1.168:8160", 0))
        if (client.openJSerial("COM7:115200")) {

            MsgBaseWriteEpc writeEpc = new MsgBaseWriteEpc();
            writeEpc.setAntennaEnable(EnumG.AntennaNo_1);
            writeEpc.setArea(EnumG.WriteArea_Reserved);//写保留区
            //写入访问密码
            writeEpc.setStart(2);//word  前4个字节代表销毁密码 后4个字节代表访问密码
            String pas = "12345678";
            writeEpc.setHexWriteData(pas);
            client.sendSynMsg(writeEpc);
            if (0x00 == writeEpc.getRtCode()) {
                System.out.println("Write successful." + "pas-->12345678");
            } else {
                System.out.println(writeEpc.getRtMsg());
            }
        }
    }
}
