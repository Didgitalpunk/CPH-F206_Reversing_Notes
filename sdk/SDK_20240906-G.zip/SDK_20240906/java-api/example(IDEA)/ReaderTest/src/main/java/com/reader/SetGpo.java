package com.reader;

import com.gg.reader.api.dal.GClient;
import com.gg.reader.api.protocol.gx.MsgAppSetGpo;

import java.util.Scanner;

public class SetGpo {
    public static void main(String[] args) {
        GClient client = new GClient();
        //        if (client.openTcp("192.168.1.168:8160", 0))
         if (client.openJSerial("COM7:115200")) {

            //高低电平切换会发出声响

            MsgAppSetGpo msg = new MsgAppSetGpo();
            msg.setGpo1(1);//gpo1 设置高电平
            client.sendSynMsg(msg);
            if (0x00 == msg.getRtCode()) {
                System.out.println("Set success");
            } else {
                System.out.println(msg.getRtMsg());
            }

            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }

            msg.setGpo1(0);//gpo1 设置低电平
            client.sendSynMsg(msg);
            if (0x00 == msg.getRtCode()) {
                System.out.println("Set success");
            } else {
                System.out.println(msg.getRtMsg());
            }

        }
    }
}
