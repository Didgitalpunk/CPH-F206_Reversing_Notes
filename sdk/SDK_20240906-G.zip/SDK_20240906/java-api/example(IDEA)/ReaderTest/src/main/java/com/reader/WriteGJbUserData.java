package com.reader;

import com.gg.reader.api.dal.GClient;
import com.gg.reader.api.protocol.gx.EnumG;
import com.gg.reader.api.protocol.gx.MsgBaseWriteGJb;

import java.util.Scanner;

public class WriteGJbUserData {
    public static void main(String[] args) {
        GClient client = new GClient();
        //        if (client.openTcp("192.168.1.168:8160", 0))
       if (client.openJSerial("COM7:115200")) {

            MsgBaseWriteGJb msg = new MsgBaseWriteGJb();
            msg.setAntennaEnable(EnumG.AntennaNo_1);
            msg.setStart(0);
            //0x03，用户数据区
            msg.setArea(0x03);
            String data = "1234AAAA";
            int len = PcUtils.getValueLen(data);
            String s = PcUtils.padLeft(data, len * 4, '0');
            msg.setHexWriteData(s);

            //匹配tid写
//            String tid = "E280110520007B05A8C208A8";
//            ParamEpcFilter filter = new ParamEpcFilter();
//            filter.setArea(0x00);
//            filter.setHexData(tid);
//            filter.setBitStart(0);
//            filter.setBitLength(tid.length() * 4);
//            msg.setFilter(filter);

            client.sendSynMsg(msg);
            if (0x00 == msg.getRtCode()) {
                System.out.println("Write successful.");
            } else {
                System.out.println(msg.getRtMsg());
            }
        }
    }
}
