package com.reader;

import com.gg.reader.api.dal.GClient;
import com.gg.reader.api.protocol.gx.EnumG;
import com.gg.reader.api.protocol.gx.MsgBaseWriteGb;

public class WriteGbSafe {
    public static void main(String[] args) {
        GClient client = new GClient();
        //        if (client.openTcp("192.168.1.168:8160", 0))
       if (client.openJSerial("COM7:115200")) {


            MsgBaseWriteGb msg = new MsgBaseWriteGb();
            msg.setAntennaEnable(EnumG.AntennaNo_1);
            //0x10:标签编码区 | 0x20:标签安全区 | 0x30~0x3F:用户子区0~15
            msg.setArea(0x20);//安全区
            msg.setStart(2);//word 0-1灭活口令  2-3锁定口令

            //匹配标签写
//            String tid = "E280110520007B05A8C208A8";
//            ParamEpcFilter filter = new ParamEpcFilter();
//            filter.setArea(0x00);
//            filter.setHexData(tid);
//            filter.setBitStart(0);
//            filter.setBitLength(tid.length() * 4);
//            msg.setFilter(filter);


            String data = "12345678";
            msg.setHexWriteData(data);

            client.sendSynMsg(msg);
            if (0x00 == msg.getRtCode()) {
                System.out.println("Write successful.");
            } else {
                System.out.println(msg.getRtMsg());
            }
        }
    }
}
